package com.cg.chatbox.dto;

import java.util.List;

import org.springframework.stereotype.Component;

@Component("chathistory")
public class ChatHistory {
	private User user;
	private List<Message> message;

	public ChatHistory() {

	}

	public ChatHistory(List<Message> message) {
		super();
		this.message = message;
	}

	public List<Message> getMessage() {
		return message;
	}

	public void setMessage(List<Message> message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return "ChatHistory [message=" + message + "]";
	}
	
	

	
}
