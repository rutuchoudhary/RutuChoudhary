package com.cg.chatbox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.chatbox.dao.ChatHistoryDaoImpl;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;

/**
 * This is the Service class which is the implementation of service interface
 * @Author Rutuja Choudhary
 */

@Service("chathistoryservice") /** @Service annotation is used with classes that provide some business
								 *          functionalities.
								 */
public class ChatHistoryServiceImpl implements ChatHistoryService {
	@Autowired
	ChatHistoryDaoImpl dao;

	public Message addMessage(Message message) {
		return dao.saveMessage(message);
	}

	public List<Message> searchBySenderOrReceiver(User user) {
		List<Message> msgList = dao.findBySenderOrReceiver(user);
		if (msgList.isEmpty()) {
			throw new UserException("There are no messages against entered id because no user with this id");
		}
		return msgList;
	}

	public ChatHistory addChatHistory(ChatHistory chathistory) {
		return dao.saveChatHistory(chathistory);
	}

	public List<ChatHistory> getAllChatHistory() {
		List<ChatHistory> chat = dao.getAllChatHistory();
		if (chat.isEmpty()) {
			throw new UserException("No Messages Added Yet");
		}
		return chat;
	}

}
