package com.cg.chatbox.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.chatbox.dao.ChatHistoryDaoImpl;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

@Service("chathistoryservice")
public class ChatHistoryServiceImpl implements ChatHistoryService {
	@Autowired
	ChatHistoryDaoImpl dao;

	public Message addMessage(Message message) {
		return dao.saveMessage(message);
	}

	public List<Message> searchBySenderOrReceiver(User user) {
		return dao.findBySenderOrReceiver(user);
	}

	public List<ChatHistory> getAllChatHistory() {
		return dao.getAllChatHistory();
	}

	public ChatHistory addChatHistory(ChatHistory chathistory) {
		return dao.saveChatHistory(chathistory);
	}

}
