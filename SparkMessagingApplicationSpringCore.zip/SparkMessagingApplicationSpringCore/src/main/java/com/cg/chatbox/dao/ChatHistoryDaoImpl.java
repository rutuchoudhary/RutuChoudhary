package com.cg.chatbox.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.util.DBUtil;

@Repository("chathistorydao")
public class ChatHistoryDaoImpl implements ChatHistoryDao {
	List<Message> messageList = new ArrayList<Message>();
	@Autowired
	List<ChatHistory> chatHistoryList;

	public Message saveMessage(Message message) {
		int count = 0;
		DBUtil.messages.add(message);
		return message;
	}

	public List<Message> findBySenderOrReceiver(User user) throws UserException {

		for (Message m : DBUtil.messages)
			if (m.getSender().getId() == user.getId() || m.getReceiver().getId() == user.getId())
				messageList.add(m);

		if (messageList.isEmpty())
			throw new UserException("There are no messages against entered id because no user with this id");

		return messageList;
	}

	public ChatHistory saveChatHistory(ChatHistory chathistory) {
		DBUtil.chathistory.add(chathistory);
		return chathistory;
	}

	public List<ChatHistory> getAllChatHistory() {
		System.out.println(DBUtil.chathistory);
		return DBUtil.chathistory;

	}

}
