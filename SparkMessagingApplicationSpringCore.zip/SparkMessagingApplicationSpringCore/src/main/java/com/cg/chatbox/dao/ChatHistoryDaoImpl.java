package com.cg.chatbox.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.util.DBUtil;

/**
 * This is the Repository class which makes connectivity with database in the project.
 * @Author Rutuja Choudhary
 */

/**
 * @Repository annotation is used to indicate that the class provides the mechanism for 
 * storage, retrieval, search operation on objects.
*/
@Repository("chathistorydao")
public class ChatHistoryDaoImpl implements ChatHistoryDao {
	List<Message> messageList = new ArrayList<Message>();
	@Autowired
	List<ChatHistory> chatHistoryList;

	/**
	 * This is the saveMessage method which adds the messages in the list.
	 * @param here object of message is passed as an argument
	 * @return object of Message.
	 */
	public Message saveMessage(Message message) {
		DBUtil.messages.add(message);
		return message;
	}

	/**
	 * This is the searchMessage method which searches the messages previously added in the list against user.
	 * @Exception when we want to retrieve the messages against user who is not yet saved it throws the exception No messages.
	 * @param here object of User is passed as argument here 
	 * @return List of Message.
	 */
	
	public List<Message> findBySenderOrReceiver(User user) throws UserException {
		for (Message m : DBUtil.messages)
			if (m.getSender().getId() == user.getId() || m.getReceiver().getId() == user.getId()) {
				messageList.add(m);
			}
		return messageList;
	}

	
	/**
	 * This is the saveChatHistory method which adds the chat history to the list.
	 * @param here object of chathistory is passed as an argument
	 * @return object of chathistory.
	 */
	
	public ChatHistory saveChatHistory(ChatHistory chathistory) {
		DBUtil.chathistory.add(chathistory);
		return chathistory;
	}
	
	/**
	 * This is the getAllChatHistory method which retrieves all the messages previously added in the list of chathistory against user.
	 * @exception when there are no messages in the list then it will throws the exception No Chathistory yet.
	 * @param here object of chathistory is passed as an argument
	 * @return List of chathistory.
	 */

	public List<ChatHistory> getAllChatHistory() {
		return DBUtil.chathistory;

	}

}
