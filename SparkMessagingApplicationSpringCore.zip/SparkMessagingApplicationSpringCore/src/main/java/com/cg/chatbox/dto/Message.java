package com.cg.chatbox.dto;

import java.sql.Timestamp;

import org.springframework.stereotype.Component;

@Component("message")
public class Message {
	private String text;
	private Timestamp date;
	private User sender;
	private User receiver;

	public Message() {
	}

	public Message(String text, Timestamp date, User sender, User receiver) {
		super();
		this.text = text;
		this.date = date;
		this.sender = sender;
		this.receiver = receiver;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public User getSender() {
		return sender;
	}

	public void setSender(User sender) {
		this.sender = sender;
	}

	public User getReceiver() {
		return receiver;
	}

	public void setReceiver(User receiver) {
		this.receiver = receiver;
	}

	@Override
	public String toString() {
		return "Message [text=" + text + ", date=" + date + ", sender=" + sender + ", receiver=" + receiver + "]";
	}

}
