package com.cg.chatbox.dto;

import java.sql.Timestamp;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

/**
 * This is the DTO class of Message 
 * @Author Rutuja Choudhary
 */

@Component("message")								/** @Component annotation is used to denote a class as Component */
@Scope("prototype")
public class Message {
	private String text;						/** This attribute is used to accept the message text in string format*/
	private Timestamp date;						/** This attribute is used to display date and time in Timestamp format*/
	private User sender;						
	private User receiver;

	public Message() {
	}

	public Message(String text, Timestamp date, User sender, User receiver) {
		super();
		this.text = text;
		this.date = date;
		this.sender = sender;
		this.receiver = receiver;
	}

	/** calling getters and setter */
	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public User getSender() {
		return sender;
	}

	public void setSender(User sender) {
		this.sender = sender;
	}

	public User getReceiver() {
		return receiver;
	}

	public void setReceiver(User receiver) {
		this.receiver = receiver;
	}

	/** creating toString */
	@Override
	public String toString() {
		return "Message [text=" + text + ", date=" + date + ", sender=" + sender + ", receiver=" + receiver + "]";
	}

}
