import {Component,OnInit} from '@angular/core';
import {MessageService} from './app.messageservice';
import {Message} from './app.message';
import {User} from './app.user';
import {ChatHistory} from './app.chathistory';


@Component({
    selector:'msg-app',
    templateUrl:'app.showmessage.html'
})


export class ShowMessage implements OnInit{
    messages:Message[] =[];
    // model:any={};
    constructor(private msgservice:MessageService){
        // console.log("In Show Constructor");
    }

    ngOnInit(){
        console.log("In Method");
        console.log("ngonit console...."+this.msgservice.showChatHistory().subscribe((data:Message[])=>this.messages=data));
       this.msgservice.showChatHistory().subscribe((data:Message[])=>this.messages=data);
    }
}