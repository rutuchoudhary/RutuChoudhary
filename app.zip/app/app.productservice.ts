import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
    providedIn:'root'
})

export class ProductService{
    constructor(private http:HttpClient) {}

    getAllProduct() {                                   //:Observable<Object>..... doesn't matter if we write it or not. It is going to give us the bulk of data
        // return this.http.get("assets/product.json");
         return this.http.get("http://localhost:9098/product/show");            // to get data from springboot application
    }

addAllProduct(prod:any){
    return this.http.post("http://localhost:9098/product/add",prod);
}
}