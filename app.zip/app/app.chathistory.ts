import {Message} from './app.message';
import {User} from './app.user';

export class ChatHistory{
    user:User;
    message:Message[];
}

