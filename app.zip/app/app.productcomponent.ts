import {Component,OnInit} from '@angular/core';
import {ProductService} from './app.productservice';
import {Product} from './app.product';


@Component({
    selector:'prod-app',
    templateUrl:'app.product.html'
})
export class ProductComponent implements OnInit{
    products:Product[];
    pro:any={"id":1030,"name":"Kahipn","price":500,"description":"ugach ghetla"
    ,"inventory":{"id":111,"name":"Mazi Inventory"}}
    constructor(private proservice:ProductService) {
        console.log("In Constructor");
    }

    ngOnInit() {
        console.log("In OnInit");
        this.proservice.getAllProduct().subscribe((data:Product[])=>this.products=data);
    }

addProduct() {
    this.proservice.addAllProduct(this.pro).subscribe((data)=>console.log(data));

    }
}
}