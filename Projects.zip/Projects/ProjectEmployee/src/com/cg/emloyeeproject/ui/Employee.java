package com.cg.emloyeeproject.ui;

import java.util.Scanner;

public class Employee {

	private int id;
	private String name;
	private double salary;
	private String designation;

	
 public Employee() {
	 
 }
	
 	public Employee(int id, String name, double salary, String designation) {
	super();
	this.id = id;
	this.name = name;
	this.salary = salary;
	this.designation = designation;
}


	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", designation=" + designation + "]";
	}

	void Output() {
//	 Employee[] emp= new Employee[2];
	 Scanner scr = new Scanner(System.in);
	 System.out.println("Enter Employee ID: ");
	 id= scr.nextInt();
	 System.out.println("Enter Employee Name: ");
	 name= scr.next();
	 System.out.println("Enter Employee salary: ");
	 salary= scr.nextDouble();
	 System.out.println("Enter Employee Designation: ");
	 designation= scr.next();
	 
	 
 }
 
 public void Details() {
	 
	 {
         System.out.print("The Details are: " );
         System.out.println("Employee Id:" +id+ " Employee Name:" +name + " Employee Salary:"+salary + " Employee Designation:"+designation);
        // System.out.println("Employee" + id + "");
 }
}
}