package com.cg.emloyeeproject.ui;

import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int choice1;
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter Number of Employees you want to display: ");
		int n = scr.nextInt();
		
		Employee[] emp= new Employee[n];
//		choice1 =scr.nextInt();
		
		emp=new Employee[n];
		
		for(int i=0;i<n;i++)
		emp[i] = new Employee();
		
//		while (choice1 < 3)
		do{
			System.out.println("Enter your choice:");
			System.out.println("1.Add details");
			System.out.println("2.Show details");
			System.out.println("3.Exit");
			choice1 =scr.nextInt();
			
			
		switch(choice1) {
		case 1: 
			for(int i=0; i<n; i++) {
			System.out.println("Enter Employee Details:");
			emp[i].Output();
			}
		break;
			
		case 2:
			for(int i=0; i<n;i++) {
			System.out.println("Show details:");
			emp[i].Details();
			}
			break;
			
		case 3:
			System.exit(1);
			break;
		
//			default:
//			break;
		
		}
	} while(choice1 !=0);
}

}
