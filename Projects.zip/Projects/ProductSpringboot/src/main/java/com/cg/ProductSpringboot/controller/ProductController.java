package com.cg.ProductSpringboot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ProductSpringboot.dto.Inventory;
import com.cg.ProductSpringboot.dto.Product;
import com.cg.ProductSpringboot.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {

	@Autowired
	ProductService productservice;

	/*
	 * // @GetMapping("checkname")
	 * 
	 * @RequestMapping(method = RequestMethod.GET, value = "/checkname/{uname}")
	 * public String getName(@PathVariable("uname") String
	 * mname, @RequestParam("prodid") String id) { return id + " Capgemini " +
	 * mname; }
	 * 
	 * @RequestMapping(method = RequestMethod.POST, value = "/checkname") public
	 * String getData(@RequestParam("prodId") int pid, @RequestParam("prodName")
	 * String pname,
	 * 
	 * @RequestParam("prodPrice") String pprice) { System.out.println(pid + " " +
	 * pname + " " + " " + pprice); return "Welcome"; }
	 */

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product> addProduct(@RequestBody Product pro) {
		System.out.println(pro);
		Product prod = productservice.addProduct(pro);
		if (prod == null) {
			return new ResponseEntity("Product Not added", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Product>(prod, HttpStatus.OK);
	}

	@RequestMapping(value = "/show", method = RequestMethod.GET)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<List<Product>> showAllProduct() {
		List<Product> myList = productservice.showAll();
		if (myList.isEmpty()) {
			return new ResponseEntity("No Product To Show", HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity<List<Product>>(myList, HttpStatus.OK);
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product> search(@RequestBody Product pro) {
		List<Product> proList = productservice.searchByName(pro.getName());
		if (proList.isEmpty()) {
			return new ResponseEntity("Product not added", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(proList, HttpStatus.OK);
	}

	@RequestMapping(value = "/find", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product> find(@RequestParam("maxprice") double maxprice,
			@RequestParam("minprice") double minprice) {
		List<Product> prodList = productservice.searchByPriceBetween(maxprice, minprice);
		if (prodList.isEmpty()) {
			return new ResponseEntity("No product in the Database", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(prodList, HttpStatus.OK);
	}

	@RequestMapping(value = "/addall", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product> addAll(@RequestParam("id") int pid, @RequestParam("name") String name,
			@RequestParam("price") double price, @RequestParam("descrption") String description,
			@RequestParam("intventid") int inventid, @RequestParam("inventname") String inventname) {
		Inventory inventory = new Inventory();
		inventory.setId(inventid);
		inventory.setName(inventname);

		Product product = new Product();
		product.setId(pid);
		product.setName(name);
		product.setPrice(price);
		product.setDescription(description);
		product.setInventory(inventory);

		Product prod = productservice.addProduct(product);
		if (prod == null) {
			return new ResponseEntity("No product in this range", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(prod, HttpStatus.OK);
	}

	
	//Alternate way
	@RequestMapping(value = "/addallthings", method = RequestMethod.POST)
	@CrossOrigin(origins="http://localhost:4200")
	public ResponseEntity<Product> addAll(@ModelAttribute Product prod) {
		Product pro= productservice.addProduct(prod);
		if (pro == null) {
			return new ResponseEntity("No product in this range", HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity(pro, HttpStatus.OK);
	}

	
	
	
	/*
	 * @RequestMapping(value = "/search", method = RequestMethod.POST) public
	 * Product searchProduct(@RequestBody Product pro) { return
	 * productservice.searchById(pro.getId()); }
	 * 
	 * @RequestMapping(value="/delete",method=RequestMethod.DELETE) public void
	 * deleteproduct(@RequestBody Product pro) { Product
	 * pr=productservice.searchById(pro.getId()); productservice.deleteProduct(pr);
	 * }
	 * 
	 * @RequestMapping(value="/update",method=RequestMethod.PUT) public Product
	 * updateProduct(@RequestBody Product pro) { Product p =
	 * productservice.searchById(pro.getId()); p.setName(pro.getName());
	 * p.setPrice(pro.getPrice()); p.setDescription(pro.getDescription());
	 * productservice.updateProduct(p); return p;
	 * 
	 * }
	 */
}
