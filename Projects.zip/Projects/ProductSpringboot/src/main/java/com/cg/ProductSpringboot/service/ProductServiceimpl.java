package com.cg.ProductSpringboot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProductSpringboot.dao.ProductDao;
import com.cg.ProductSpringboot.dto.Product;

@Service
public class ProductServiceimpl implements ProductService {
	@Autowired
	ProductDao productdao;

	@Override
	public Product addProduct(Product pro) {
		return productdao.save(pro);
	}

	@Override
	public List<Product> showAll() {
		return productdao.findAll();
	}

	@Override
	public List<Product> searchByName(String name) {
		return productdao.findByName(name);
	}

	@Override
	public List<Product> searchByPriceBetween(double max, double min) {
		return productdao.findByPriceBetween(max, min);
	}

	/*
	 * @Override public Product searchById(int id) { return productdao.findById(id);
	 * }
	 * 
	 * @Override public void deleteProduct(Product prod) {
	 * productdao.deleteProduct(prod); }
	 * 
	 * @Override public Product updateProduct(Product prod) { return prod; }
	 */
}
