package com.cg.ProductSpringboot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.ProductSpringboot")
public class ProductSpringbootApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductSpringbootApplication.class, args);
		System.out.println("welcome");
	}

}
