package com.cg.ProductSpringboot.service;

import java.util.List;

import com.cg.ProductSpringboot.dto.Product;

public interface ProductService {
	public Product addProduct(Product pro);

	public List<Product> showAll();

	public List<Product> searchByName(String name);

	public List<Product> searchByPriceBetween(double max, double min);

	/*
	 * public void deleteProduct(Product prod);
	 * 
	 * public Product updateProduct(Product prod);
	 */

}
