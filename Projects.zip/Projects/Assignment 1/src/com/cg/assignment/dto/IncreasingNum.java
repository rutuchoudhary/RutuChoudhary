package com.cg.assignment.dto;

public class IncreasingNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		public int IncreNum(int number) {
			boolean flag = false;
		       int currentDigit = number % 10;
		       number = number/10;
		        
		       
		       while(number>0){
		           
		           if(currentDigit <= number % 10){
		               flag = true;
		               break;
		           }
		           currentDigit = number % 10;
		           number = number/10;
		           
		           
		}
	}
		
	}
}
