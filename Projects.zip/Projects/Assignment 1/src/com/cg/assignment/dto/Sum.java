package com.cg.assignment.dto;

import java.util.Scanner;

public class Sum
{
		// TODO Auto-generated method stub
	
		
		public static void main(String[] args)
		{
			
		Scanner scr = new Scanner(System.in);
		System.out.println("Enter the value of i : ");
		int i  = scr.nextInt();
	    Sum s =new Sum();
	    System.out.println(s.Sum(i));
//		int sum = scr.nextInt();
		
	}
		
		public int Sum(int n )
		{
			int sum=0;
			for(int i=1;i<=n;i++) {
			if(i%3 == 0 || i%5==0) {
				sum=sum+i;
//				System.out.print("Sum is" );
//				System.out.println(sum);
			}
			
		}
			return sum;
		}
		

}

