package com.cg.assignment.dto;

import java.util.Scanner;

public class SquareDiff {
	
	public int SumOfSquare(int n) {
		int a=0;
		for(int i=1;i<=n;i++) {
			a=a+(i*i);
		}
		
		return a;
	}
	
	public int SquareOfSum(int n) {
		int b=0;
		for(int i=1;i<=n;i++) {
			b=b+i;
		}
		b=(b*b);
		return b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr =new Scanner(System.in);
		int n=scr.nextInt();		
		System.out.println("Enter the number: ");
		
		SquareDiff sd = new SquareDiff();
		sd.SumOfSquare(n);
		sd.SquareOfSum(n);
		System.out.println("Diff is: "+(sd.SumOfSquare(n)-sd.SquareOfSum(n)));
		
	}

}
