package com.cg.DemoOne.ui;

import java.util.Scanner;

import com.cg.DemoOne.dto.Employee;
import com.cg.DemoOne.dto.Project;

public class MyApplication {
	public static void main(String[] args) {
//		System.out.print("Hello.." +args[0]);
//		System.out.println(" " +args[1]);
		//Employee empOne=new Employee();
		
		//Employee emp=new Employee(17,"Rutuja",10000, 100.76);
		
		//emp.getlogin();
		//emp.getlogout();
		
		Employee emp=new Employee();
		Project project=new Project();
		
		Scanner scr =new Scanner(System.in);			//Scanner
		System.out.println("Enter The Name : ");
		String name =scr.nextLine();
		System.out.println("Enter the Id");
		int id=scr.nextInt();
		System.out.println("Enter the salary");
		double sal=scr.nextDouble();
		
		System.out.println("Enter Project Id");
		int projectId =scr.nextInt();
		System.out.println("Enter Project Name");
		String projectName= scr.next();
		System.out.println("Enter project Description");
		String projectDes =scr.next();
	
		
		
//		int id=Integer.parseInt(args[0]);					Wrapper class
//		String name = args[1];
//		double sal=Double.parseDouble(args[2]);
//		String deg=args[3];
//		
//		int projectId = Integer.parseInt(args[4]);
//		String projectName =args[5];
//		double projectCost =Double.parseDouble(args[6]);
//		String projectDes = args[7];
//		
		emp.setEmpid(id);
		emp.setEmpname(name);
		emp.setEmpsalary(sal);	
		
		project.setprojectId(projectId);
		project.setprojectName(projectName);
		project.setprojectDes(projectDes);
		
		
		emp.setproject(project);
		
		
		
//		
//		Employee empone=new Employee();
//		Project projectone=new Project();
//		empone.setEmpid(2);
//		empone.setEmpname("Choudhary");
//		
//		projectone.setprojectId(2);
//		projectone.setprojectName("B");
//		
		//empone.setprojectone(project);
		
		//System.out.println("Id of Employee is : " +emp.getEmpId());
		//System.out.println("Name of Employee is : " +emp.getEmpName());
		//System.out.println("Salary of Employee is : " +emp.getEmpSalary());
		
		
		/*
		//Project projectOne = new Project();
		Project project =new Project();
			
		project.setprojectId(1);
		
		System.out.println("Id of project is : " +project.getprojectId());
		//System.out.println(" Name of project is : " +);
		//System.out.println(" Salary of project is : " +);
		
		 */
		System.out.print(emp.getproject().getprojectId());	
		System.out.println(emp.getproject().getprojectName());    
		System.out.println(emp.getproject().getprojectDes());				//toString output
	}
	
}
