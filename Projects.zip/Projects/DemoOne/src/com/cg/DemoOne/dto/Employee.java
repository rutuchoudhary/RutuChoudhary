package com.cg.DemoOne.dto;

public class Employee {
	
	private int empId;			//0
	private String empName;		//NULL
	private double empSalary;	//0.0
	private String empDeg;		//NULL
//	private char gender;		//space or /u
//	private boolean emp;		//false
	private Project project;
	
	public Employee() {
		System.out.println("In Consturctor");
	}

	public Employee(int id, String name, double sal) {
		this.empId =id;
		this.empName=name;
		this.empSalary=sal;
		
		//this.empPF=pf;
	}
	public void getlogin() {
		int local=1;
		System.out.println("Logged In");
		System.out.println("Id is "+this.empId);
		System.out.println("Name is "+this.empName);
		System.out.println("Salary is "+this.empSalary);
		//System.out.println("PF is" +this.empPF);
		System.out.println(local);
	}
	
	public void getlogout() {
		System.out.println("Logged Out");
		
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpid(int empId) {
		this.empId=empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpname(String empName) {
		this.empName=empName;
	}
	public double getEmpSalary() {
		return empSalary;
	}
	public void setEmpsalary(double empSalary) {
		this.empSalary=empSalary;
	}
	public String getEmpDeg() {
		return empDeg;
	}
	public void setEmpDeg(String empDeg) {
		this.empDeg=empDeg;
	}
	public Project getproject() {
		return project;
	}
	public void setproject(Project project) {
		this.project=project;
	}

	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empDeg=" + empDeg
				+ ", project=" + project + "]";
	}
	

}


