package com.cg.DemoOne.dto;

public class Project {

	private int projectId;
	private String projectName;
	private String projectDes;
	private double projectCost;

	public Project() {
		System.out.println("In Project");
	}
	
	public Project(int projectId, String projectName, String projectDes, double projectCost) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectDes = projectDes;
		this.projectCost = projectCost;
	}

	public int getprojectId() {
		return projectId;
	}
	public void setprojectId(int projectId) {
		this.projectId=projectId;
	}
	public String getprojectName() {
		return projectName;
	}
	public void setprojectName(String projectName) {
		this.projectName=projectName;
	}
	public String getprojectDes() {
		return projectDes;
	}
	public void setprojectDes(String projectDes) {
		this.projectDes=projectDes;
	}

	@Override
	public String toString() {
		return "Project [projectId=" + projectId + ", projectName=" + projectName + ", projectDes=" + projectDes
				+ ", projectCost=" + projectCost + "]";
	}

	
	
		
}		

