package com.cg.person.ui;

import java.util.HashSet;
import java.util.Set;

import com.cg.person.dto.Person;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Person person = new Person("Rutu");
		Person personone = new Person("Rutu");
		Person persontwo = new Person("Rutuja");
		Person personthree = new Person("Ritu");
		Person personfour = new Person("Rit");
		Person personfive = new Person("Rituja");
		Person personsix = new Person("Ruts");
		Person personseven = new Person("R");
		Person personeight = new Person("Rutu");
		Person personnine = new Person("Rutu");
		Person personten = new Person("Rutu");
		
		
		Set<Person> personset = new HashSet<Person>();
		
		personset.add(person);
		personset.add(personone);
//		personset.add(persontwo);
//		personset.add(personthree);
//		personset.add(personfour);
//		personset.add(personfive);
//		personset.add(personsix);
//		personset.add(personseven);
//		personset.add(personeight);
//		personset.add(personnine);
//		personset.add(personten);s
		
		
		System.out.println(personset);
	}

}
