package com.cg.demomap.ui;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

import com.cg.demomap.dto.Employee;
import com.cg.demomap.dto.EmployeeSorting;

public class MyApplication {

	public static void main(String[] args) {

		Employee<Integer,Double> emp = new Employee<Integer,Double>(1000,"RC",1000.0);
		Employee<Integer,Double> empone = new Employee<Integer,Double>(10," ",1.0);
		Employee<BigInteger,BigDecimal> empp = new Employee<BigInteger,BigDecimal>(new BigInteger("1234"),"Rutu",new BigDecimal("1234.23"));
		
		Map<Integer,Employee> myMap = new HashMap<Integer,Employee>();
		
		myMap.put(1,emp);
		myMap.put(5,empone);
		myMap.put(4,empp);
		
		
		Collection<Employee> myCollection = myMap.values();
		
		List<Employee> empList = new ArrayList<Employee>(myCollection);
		
		Collections.sort(empList, new EmployeeSorting());
		
		for(Employee e : empList) {
			System.out.println(e.getName());
		}
		
	    
		/*Map<String,Integer> myMap= new HashMap<String,Integer>();
		
		
		myMap.put("z",1);
		myMap.put("B",8);
		myMap.put("A",3);
		myMap.put("u",9);
		myMap.put("r",13);
		*/
		
		

        /*Set set = myMap.entrySet();											//sort by key
        Iterator itr = set.iterator();
        while(itr.hasNext()) {
             Map.Entry ent = (Map.Entry)itr.next();
             System.out.println(ent.getKey() +" " + ent.getValue());
             
        }*/
		
		
		//List<Map.Entry<Integer, Employee> myList = new LinkedList<Map.Entry<Integer, Employee>>
		
		
		
		/*for (Integer i : myMap.keySet()) {
//			System.out.println(i);
			System.out.println(myMap.get(i));
			
		}*/
		
		
		/*TreeMap<Integer, Employee> e = new TreeMap<>(myMap); 
		  
        e.putAll(myMap); 
  
        for (Entry<Integer, Employee> entry : e.entrySet())  
            System.out.println("Key = " + entry.getKey() +  
                         ", Value = " + entry.getValue());      */   
    }

		
		
		
		
		
		/*List<Integer> e = new ArrayList<>(myMap.keySet());
		
		Collections.sort(e);
		
		for (Integer i : e) {
//			System.out.println(i);
			System.out.println(myMap.get(i));
			
		}*/
		/*
		Map<Integer,String> myMap= new HashMap<Integer,String>();
		
		myMap.put(1000, "abcd");
		myMap.put(2000, "ABCD");
		myMap.put(1000, "Z");
		myMap.put(null, "a");
		myMap.put(300, "ABCD");
		myMap.put(1000, null);
		myMap.put(null, null);
		myMap.put(null, "A");
		myMap.put(null, null);
		*/
		
	
//		System.out.println(myMap);
	}



