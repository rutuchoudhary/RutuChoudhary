package com.cg.collection;

import static org.junit.Assert.*;

import org.hamcrest.Matcher;
import org.junit.Test;

import com.cg.collection.dto.Product;

public class ShipmentTest {
	private Shipment shipment = new Shipment();
	private Product door;
	private Product window;

	@Test
	public void shouldAddItems() throws Exception{
		shipment.add(door);
		shipment.add(window);
		
		assertThat(shipment, contains(door,window ));
	}

	private Matcher contains(Product door2, Product window2) {
		return null;
	}

}
