package com.cg.collection;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.cg.collection.dto.Product;

public class Shipment implements Iterable<Product>{
	
	private List<Product> products = new ArrayList<Product>();
	
	public void add(Product product) {
		products.add(product);
	}
	
	 

	@Override
	public Iterator<Product> iterator() {
		return products.iterator();
	}

}
