package com.cg.collection.dto;

import java.util.Comparator;

public class Product {
	
	  final Comparator<Product> BY_WEIGHT= Comparator<Product>() {
		public double compare(final Product p1, final Product p2) {
		return Double.compare(p1.getWeight(), p2.getWeight());
	}
};
	private String name;
	private double weight;
	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public Product(String name, double weight) {
		super();
		this.name = name;
		this.weight = weight;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getWeight() {
		return weight;
	}

	public void setWeight(double weight) {
		this.weight = weight;
	}

	@Override
	public String toString() {
		return "Product [name=" + name + ", weight=" + weight + "]";
	}
	
	

}
