package com.cg.collection.dto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;

public class CollectionConcepts {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Product floor = new Product("Floor", 23.4);
		Product panel = new Product("Pannel", 19);
		Product Window = new Product("Window",25);
		
		Collection<Product> product =new ArrayList<Product>();
		
		//using add()
		
		product.add(floor);
		product.add(panel);
		product.add(Window);
		
//		System.out.println(product);
		
		/*//Using iterator
		final Iterator<Product> pi = product.iterator();
		while(pi.hasNext()) {
			Product products = pi.next();
			System.out.println(products);
			
		}*/
		
		
//		Using for each loop(substitute)
		for (Product products : product) {						//collection object stored in new and printed
			if(products.getWeight()<20) {
			System.out.println(products);
			}
			else
			{
				product.remove(products);						//Exception in thread "main" java.util.ConcurrentModificationException, because we are trying to modify and iterate at the collection same time
			}
		}
	}

}
