package com.cg.jpademo.ui;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.jpademo.dto.Address;
import com.cg.jpademo.dto.Department;
import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.service.EmployeeServiceImpl;

public class MyEmployee {
	static EmployeeServiceImpl service;
	
	public static void main(String[] args) {
		
		 service = new EmployeeServiceImpl();
		
	Scanner scr =new Scanner(System.in);
	/*System.out.println("Enter Employee Id");
	int e_id = scr.nextInt();
	System.out.println("Enter Employee Name");
	String e_name = scr.next();
	System.out.println("Enter Employee Salary");
	double e_sal = scr.nextDouble();
	System.out.println("Enter the date of joining");
	String date =scr.next();
	System.out.println("Enter Department Id");
	int d_id = scr.nextInt();
	System.out.println("Enter department name");
	String d_name = scr.next();
	System.out.println("Enter City");
	String city = scr.next();
	System.out.println("Enter Pincode");
	int pc = scr.nextInt();
	System.out.println("Enter State");
	String state =scr.next();
	
	boolean type = true;
	Department dep = new Department();
	dep.setId(d_id);
	dep.setName(d_name);
	
	Address ad = new Address();
	ad.setCity(city);
	ad.setState(state);
	ad.setPincode(pc);
	
	
	Employee emp = new Employee();
	emp.setId(e_id);
	emp.setName(e_name);
	emp.setSalary(e_sal);
	emp.setType(true);
	emp.setAddr(ad);
	emp.setDateofjoining(new Date());
	emp.setDept(dep);
	*/
//	service.addEmployee(emp);

	List<Employee> myList = service.searchBySalary(3000, 8000);
	for(Employee employee:myList) {
		System.out.println("Employee Id is: "+employee.getId());
		System.out.println("Employee Name is: "+employee.getName());
		System.out.println("Employee Salary is: "+employee.getSalary());
		System.out.println("Employee Department is: "+employee.getDept().getName());
	}
	
	
	
	}
}
	