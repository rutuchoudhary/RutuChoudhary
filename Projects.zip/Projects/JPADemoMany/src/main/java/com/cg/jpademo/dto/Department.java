package com.cg.jpademo.dto;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Department {
	@Id
	@Column(name="d_id")
	private int id;
	@Column(name="d_name")
	private String name;
	@OneToMany(mappedBy="dept",cascade=CascadeType.ALL)
	private List<Employee> myEmployeeList = new ArrayList<Employee>();									//forwarding to onetomany relationship
	
	public Department() {}

	public Department(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}

	public List<Employee> getMyEmployeeList() {
		return myEmployeeList;
	}

	public void setMyEmployeeList(List<Employee> myEmployeeList) {
		this.myEmployeeList = myEmployeeList;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Department [id=" + id + ", name=" + name + "]";
	}

	
}
