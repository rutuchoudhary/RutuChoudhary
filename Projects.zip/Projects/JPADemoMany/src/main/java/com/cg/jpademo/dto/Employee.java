package com.cg.jpademo.dto;

import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity																								//to make entity
@Table(name="Employeedb")																			//to change the table name
public class Employee {
	@Id																								//primary key
	@Column(name="emp_id")																			//to give the names to columns
	private int id;
	@Column(name="emp_name")
	private String name;
	@Column(name="emp_salary")
	private double salary;
	@Column(name="emp_type")
	private boolean type;
	@Column(name="joining")
	@Temporal(TemporalType.DATE)
	private Date dateofjoining;
	@Embedded
	private Address addr;
	
	@ManyToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="dep_id")											//to change the column
	private Department dept;
	
	public Employee() {}

	public Employee(int id, String name, double salary, boolean type, Date dateofjoining, Address addr, Department dept) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
		this.type = type;
		this.dateofjoining = dateofjoining;
		this.addr = addr;
		this.dept = dept;
	}

	public Address getAddr() {
		return addr;
	}

	public void setAddr(Address addr) {
		this.addr = addr;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getSalary() {
		return salary;
	}

	public void setSalary(double salary) {
		this.salary = salary;
	}

	public boolean isType() {
		return type;
	}

	public void setType(boolean type) {
		this.type = type;
	}

	public Date getDateofjoining() {
		return dateofjoining;
	}

	public void setDateofjoining(Date dateofjoining) {
		this.dateofjoining = dateofjoining;
	}
	
	public Department getDept() {
		return dept;
	}

	public void setDept(Department dept) {
		this.dept = dept;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + ", type=" + type + ", dateofjoining="
				+ dateofjoining + ", addr=" + addr + ", dept=" + dept + "]";
	}


}

