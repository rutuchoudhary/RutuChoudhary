package com.cg.jpademo.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.jpademo.dto.Employee;
import com.cg.jpademo.util.DBUtil;

public class EmployeeDaoImpl implements EmployeeDao {
	EntityManager em;

	public EmployeeDaoImpl() {
		em =DBUtil.getConnection();
	}

	public void saveEmployee(Employee emp) {
		em.persist(emp);
		em.getTransaction().commit();
	}

	public List<Employee> findBySalary(double min, double max) {
		Query query = em.createQuery("From Employee where salary between :min and :max");
		query.setParameter("min", min);
		query.setParameter("max", max);
		List<Employee> empList = query.getResultList() ;
		return empList;
	}

	public List<Employee> findByDepartmentName(String name) {
		
		Query query = em.createQuery("select from Department as d join employee as e ");
		return null;
	}


	
}
