package com.cg.jpademo.service;

import java.util.List;

import com.cg.jpademo.dao.EmployeeDaoImpl;
import com.cg.jpademo.dto.Employee;

public class EmployeeServiceImpl implements EmployeeService{
	EmployeeDaoImpl dao;
	
	public EmployeeServiceImpl() {
		dao= new EmployeeDaoImpl();
	}
	public void addEmployee(Employee emp) {
		dao.saveEmployee(emp);
	}

	public List<Employee> searchBySalary(double min, double max) {
		return dao.findBySalary(min, max);
	}

	public List<Employee> searchByDepartmentName(String name) {
		return dao.findByDepartmentName(name);
	}

}
