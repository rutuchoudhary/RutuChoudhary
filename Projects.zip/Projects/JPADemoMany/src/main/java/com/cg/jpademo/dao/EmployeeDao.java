package com.cg.jpademo.dao;

import java.util.List;

import com.cg.jpademo.dto.Employee;

public interface EmployeeDao {
	public void saveEmployee(Employee emp);

	public List<Employee> findBySalary(double min, double max);

	public List<Employee> findByDepartmentName(String name);


}
