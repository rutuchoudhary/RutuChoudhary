package com.cg.employeejdbcdemo.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.employeejdbcdemo.Employee;
import com.cg.employeejdbcdemo.exception.EmployeeException;

public interface EmployeeDao {
	
	public Employee save(Employee emp) throws EmployeeException; 
	public List<Employee> showAll() throws SQLException;
	public List<Employee> findEmployeeById(int id);
	public Employee update(int id);

}
