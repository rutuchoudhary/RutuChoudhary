package com.cg.employeejdbcdemo.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.employeejdbcdemo.exception.EmployeeException;

public class Dbutil {

	static Connection conn;

	public static Connection getConnection() throws EmployeeException {
		Properties prop = new Properties();
		try {
			InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
			prop.load(it);

//			if (conn == null) {
				if (prop != null) {

					String driver = prop.getProperty("jdbc.Driver");
					String url = prop.getProperty("jdbc.url");
					String uname = prop.getProperty("jdbc.username");
					String upass = prop.getProperty("jdbc.password");
					//Class.forName(driver);
					conn = DriverManager.getConnection(url, uname, upass);
				}
//			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new EmployeeException("File not found!");
		} catch (IOException e) {
			e.printStackTrace();
			throw new EmployeeException("File not open!");
		} catch (SQLException e) {
			e.printStackTrace();
			throw new EmployeeException("Connection not established!");
		}
		return conn;
	}
}
