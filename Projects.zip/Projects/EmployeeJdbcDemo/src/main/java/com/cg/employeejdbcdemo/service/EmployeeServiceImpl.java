package com.cg.employeejdbcdemo.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.employeejdbcdemo.Employee;
import com.cg.employeejdbcdemo.dao.EmployeeDaoImpl;
import com.cg.employeejdbcdemo.exception.EmployeeException;

public class EmployeeServiceImpl implements EmployeeService {

	EmployeeDaoImpl dao = new EmployeeDaoImpl();
	public Employee add(Employee emp) throws EmployeeException {
		return dao.save(emp);
	}

	public List<Employee> searchEmployeeByName(String name) {
		return null;
	}

	public List<Employee> showAll() throws SQLException {
		return dao.showAll();
	}

	public Employee update(int id) throws EmployeeException {
		return null;
	}

}
