package com.cg.employeejdbcdemo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.employeejdbcdemo.Employee;
import com.cg.employeejdbcdemo.exception.EmployeeException;
import com.cg.employeejdbcdemo.util.Dbutil;

public class EmployeeDaoImpl implements EmployeeDao {

	public Employee save(Employee emp) throws EmployeeException {
		Connection con = Dbutil.getConnection();
		String query_insert = "Insert into employeedetails values(?,?,?)";
		PreparedStatement pstm = null;
		try {
			pstm = con.prepareStatement(query_insert);
			pstm.setInt(1, emp.getId());
			pstm.setString(2, emp.getName());
			pstm.setDouble(3, emp.getSalary());

			pstm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public List<Employee> showAll() throws SQLException {
		List<Employee> myList = new ArrayList<Employee>();
		Connection con;
		try {
			con = Dbutil.getConnection();

			String query_show = "Select id,name,salary from employeedetails";
			PreparedStatement pstm;
			pstm = con.prepareStatement(query_show);
			ResultSet result = pstm.executeQuery();
			while (result.next()) {
				Employee emp = new Employee();
				emp.setId(result.getInt("id"));
				emp.setName(result.getString("name"));
				emp.setSalary(result.getDouble("salary"));

				myList.add(emp);
			}
		} catch (EmployeeException e) {
			e.printStackTrace();
		}
		return myList;
	}

	public List<Employee> findEmployeeById(int id) {
		return null;
	}

	public Employee update(int id) {
		return null;
	}

}
