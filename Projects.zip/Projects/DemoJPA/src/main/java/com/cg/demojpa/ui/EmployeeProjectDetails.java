package com.cg.demojpa.ui;

import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.cg.demojpa.dto.Employee;
import com.cg.demojpa.dto.Project;

public class EmployeeProjectDetails {
	
	public static void main(String[] args) {

		EntityManagerFactory emf = Persistence.createEntityManagerFactory("demoemployeeproject") ;
		EntityManager em = emf.createEntityManager();
		Scanner scr = new Scanner(System.in);
		Employee emp =new Employee();
		Project pro =new Project();
		int choice=0;
		
		do {
			System.out.println("1.Add Details 2.Update Details 3.Remove 4.Project Details");
			System.out.println("Enter your choice: ");
			choice = scr.nextInt();
			switch(choice) {
			case 1:
				em.getTransaction().begin();
				System.out.println("Enter Employee Id:");
				int emp_id = scr.nextInt();
				System.out.println("Enter Employee Name: ");
				String emp_name = scr.next();
				System.out.println("Enter Employee Salary: ");
				double emp_salary=scr.nextDouble();
				System.out.println("Enter Project Id: ");
				int proj_id =scr.nextInt();
				System.out.println("Enter Project Name: ");
				String proj_name=scr.next();
				
				pro.setId(proj_id);
				pro.setName(proj_name);
				emp.setId(emp_id);
				emp.setName(emp_name);
				emp.setSalary(emp_salary);
				emp.setProj(pro);
				em.persist(emp);
				em.persist(pro);
				em.getTransaction().commit();
				
				break;
				
			case 2:
				 em.getTransaction().begin();
	    		 System.out.println("Enter Employee Id");
	    		 int id =scr.nextInt();
	    		 System.out.println("Enter Employee Name to be updated: ");
	    		 String Emp_Name = scr.next();
	    		 System.out.println("Enter Employee Salary to be updated: ");
	    		 double Emp_Salary = scr.nextDouble();
	    		 System.out.println("Enter Project Name to be updated: ");
	    		 String Proj_Name = scr.next();
	    		 Employee ee =em.find(Employee.class,id);  
	    		 System.out.println("After Update");
	    		 ee.setName(Emp_Name);
	    		 ee.setSalary(Emp_Salary);
	    		 if(ee.getProj().getId()==pro.getId()) {
	    			 ee.getProj().setName(Proj_Name);
	    		 }
	    		 em.getTransaction().commit();
	    		 break;
	    		 
			case 3:
				 em.getTransaction().begin();
				 System.out.println("Enter Employee Id To Be Removed: ");
				 int e_id = scr.nextInt();
				 Employee remove = em.find(Employee.class, e_id);
				 em.remove(remove);
				 em.getTransaction().commit();
	    		 break;
	    		 
			case 4:
				 em.getTransaction().begin();
				 System.out.println("Enter Project Id: ");
				 int pr_id = scr.nextInt();
				 Project pr = em.find(Project.class, pr_id);
				 pr.getName();
				 if(pr_id==emp.getProj().getId()) {
					  System.out.println(emp.getName()+" "+emp.getId()+" "+emp.getSalary());
				 }
				 em.getTransaction().commit();
				 em.close();
				 break;
				 
				 
				 
	    		  
			}
			
			
		}while(choice!=0);
	
	}

}
