package com.cg.demotesttwo.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.StringTokenizer;

public class Information {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		InputStream fileread = null ;
		OutputStream filewrite = null;
		
		
		try {
			fileread = new FileInputStream("D:/Assignment.txt");
			filewrite = new FileOutputStream("D:/AssignmentWritten.txt");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		StringTokenizer str= new StringTokenizer("D:/Assignment.txt");
		System.out.println(str);
		try {
			while((str=fileread.read())!= null) {
//				StringTokenizer str= new StringTokenizer("D:/Assignment.txt");
				System.out.println(str.hasMoreTokens());
//				
				while(str.hasMoreTokens()) {
					
//					filewrite.write(str);
					System.out.println(str.nextToken());
				}
				
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Not Found");
		}
		
	}

}


























