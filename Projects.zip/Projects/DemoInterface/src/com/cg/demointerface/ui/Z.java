package com.cg.demointerface.ui;

public class Z {
protected int mydata = 8;
	public void getData() {
		System.out.println("In Non-Static");
	}
	
	public void getStaticData() {
		System.out.println("In Static");
	}
}
