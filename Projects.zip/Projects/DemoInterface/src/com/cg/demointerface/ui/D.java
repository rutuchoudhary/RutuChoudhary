package com.cg.demointerface.ui;

public class D implements A,B,C {					//The B and C interface have same methods but only one is implemented in D class.

	@Override
	public void setData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		
	}
	
	
	static void getStaticAll() {
		String name="Cap";
		System.out.println("Hii");
	}
	
}













/*implements B {

	@Override
	public void getData() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void printAll() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setData() {
		// TODO Auto-generated method stub
		
	}

}

*/