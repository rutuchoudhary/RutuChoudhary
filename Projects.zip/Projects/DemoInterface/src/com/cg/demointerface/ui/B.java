package com.cg.demointerface.ui;

public interface B {
	
	public void setData();
}


/*
extends A {															//we can extends one interface of any class.

	public void setData();
}
*/