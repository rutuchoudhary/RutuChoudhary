package com.cg.demointerface.ui;

public class MyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(Math.PI);
		
		A temp = new D();
		temp.getDefaultAll();
		A.getStaticAll();
		D demo = new D();
		D.getStaticAll();
//		demo.getStaticAll();
		
		/*									non static inheritance
		Z temp =new Y();
		temp.getData();								
		temp.getStaticData();
		*/
		
//		Timing temp = new DayShift();
//		System.out.println(temp.time);
//		temp.getLogin();
//		temp.getLogout();
//		temp.getCompany();
	}

}
