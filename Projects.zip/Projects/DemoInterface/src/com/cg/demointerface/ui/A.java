package com.cg.demointerface.ui;

public interface A {

	public void getData();
	public void printAll();
	
	
	default void getDefaultAll() {
		String name="Cap";
		System.out.println("Hey");
	}
	
	static void getStaticAll() {
		String name="Cap";
		System.out.println("Hii A");
	}
	
}


