package com.cg.demointerface.ui;

public interface Timing {

	double time=9.5;				//Final
	public void getLogin();					//Public abstract void getlogin;(compiler gives or thinks)
	public void getLogout();
	public void getCompany();
}
