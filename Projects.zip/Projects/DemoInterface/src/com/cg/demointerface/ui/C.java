package com.cg.demointerface.ui;

public interface C {

	public void setData();
}
