package com.cg.demointerface.ui;

public class Y extends Z {
	
	public void getData() {
		System.out.println("In Y Non-Static" +mydata);
	}
	
	public void getStaticData() {
		System.out.println("In Y Static");
	}

}
