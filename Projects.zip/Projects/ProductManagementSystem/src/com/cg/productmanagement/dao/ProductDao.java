package com.cg.productmanagement.dao;

import com.cg.productmanagement.dto.Product;

public class ProductDao implements IProductDao {

	int i = 0;
	Product prod[];

	public ProductDao() {
		prod = new Product[5];
	}

	@Override
	public Product addProduct(Product pro) {

		prod[i] = new Product();
		prod[i].setId(pro.getId());
		prod[i].setName(pro.getName());
		prod[i].setPrice(pro.getPrice());
		prod[i].setDescription(pro.getDescription());
		i++;
		return pro;
	}

	@Override
	public Product[] showAllProduct() {
		return prod;
	}

}
