package com.cg.productmanagement.dto;

public interface IProductService {

	public Product addProduct(Product prod) ;
	public Product[] showAllProduct();
}
