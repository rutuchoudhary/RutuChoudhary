package com.cg.productmanagement.ui;

import java.util.Scanner;

import com.cg.productmanagement.dto.IProductService;
import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.productservice.ProductService;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		printDetail();
		Scanner scr = new Scanner(System.in);
		Product pro = new Product();
		IProductService service= new ProductService();
		
		int choice =0;
		do {
			System.out.println("Enter Your Choice: ");
			choice = scr.nextInt();
		
			switch(choice) {
			case 1 :
				System.out.println("Enter Id: ");
				int id = scr.nextInt();
				System.out.println("Enter Name: ");
				String name = scr.next();
				System.out.println("Enter Price: ");
				double price = scr.nextDouble();
				System.out.println("Enter Description: ");
				String description = scr.next();
				
				pro.setId(id);
				pro.setName(name);
				pro.setPrice(price);
				pro.setDescription(description);
				
				service.addProduct(pro);
				break;
				
			case 2 :
				System.out.println("Details are");
				
				Product[] allData = service.showAllProduct();
				for(Product product : allData) {
					System.out.println("Product Id is " +product.getId());
					System.out.println("Product Name is " +product.getName());
					System.out.println("Product Price is " +product.getPrice());
					System.out.println("Product Description is " +product.getDescription());
				}
		
				break;
				
			case 3 :
				System.out.println("Exit");
				break;
			} 
		}while(choice !=0);
		}
			
		
		
		public static void printDetail() {
			System.out.println("**********************");
			System.out.println("1. Add Product ");
			System.out.println("2. Show All Product ");
			System.out.println("3. Exit ");
		
		
		
	}

}
