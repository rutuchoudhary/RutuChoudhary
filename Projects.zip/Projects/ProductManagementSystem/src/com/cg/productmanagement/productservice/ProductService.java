package com.cg.productmanagement.productservice;

import com.cg.productmanagement.dao.IProductDao;
import com.cg.productmanagement.dao.ProductDao;
import com.cg.productmanagement.dto.IProductService;
import com.cg.productmanagement.dto.Product;

public class ProductService implements IProductService {

	IProductDao dao;
	
	public ProductService() {
		dao =new ProductDao();
	}
	
	@Override
	public Product addProduct(Product prod) {
		// TODO Auto-generated method stub
		return dao.addProduct(prod);
	}

	@Override
	public Product[] showAllProduct() {
		// TODO Auto-generated method stub
		return dao.showAllProduct();
	}
	
	

}
