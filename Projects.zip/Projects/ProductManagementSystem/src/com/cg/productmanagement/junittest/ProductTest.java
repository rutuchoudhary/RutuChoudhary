package com.cg.productmanagement.junittest;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.cg.productmanagement.dto.IProductService;
import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.productservice.ProductService;

class ProductTest {
	
	IProductService service;
	Product prod;
	
	@BeforeEach
	public void beforeTest() {
		service = new ProductService();
		prod = new Product();
		prod.setId(1001);
		prod.setName("Mobile");
		prod.setPrice(31000.0);
		prod.setDescription("It is Good mobile by LG");
	}
	
	@Test
	public void myTest() {
		assertNotNull(service.addProduct(prod));
		
	}
	@Test
	public void myTestTwo() {
		assertNotNull(service.showAllProduct());
	}
	
	@AfterEach
	public void afterTest() {
		service =null;
		
	}
}
