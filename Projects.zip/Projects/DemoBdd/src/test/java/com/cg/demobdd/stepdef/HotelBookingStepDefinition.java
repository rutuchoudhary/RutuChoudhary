package com.cg.demobdd.stepdef;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelBookingStepDefinition {
	WebDriver driver;
	By firstName;
	By lastName;
	By email;
	By button;

	@Before
	public void init() {
		driver = new ChromeDriver();
		System.setProperty("webdriver.chrome.driver", "D:\\JavaDemoRC\\DemoBdd\\mydriver\\chromedriver.exe");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.manage().window().maximize();
	}

	@After
	public void afterAll() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}

	@Given("^Hotel Booking HTML Page is given$")
	public void hotel_Booking_HTML_Page_is_given() {
		// Write code here that turns the phrase above into concrete actions
		driver.get("D:\\JavaDemoRC\\DemoBdd\\mydriver\\chromedriver.exe");
		firstName = By.xpath(""); // Path on web page where this field is located, we need to copy that path
		lastName = By.xpath("");
		email = By.id("");
		button = By.xpath("");
	}

	@When("^Clicking on Submit Button for first name validation$")
	public void clicking_on_Submit_Button_for_first_name_validation() {
		// Write code here that turns the phrase above into concrete actions
		driver.findElement(button).click();		
	}

	@Then("^alert is coming 'please fill the first name'$")
	public void alert_is_coming_please_fill_the_first_name() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		String actualData =driver.switchTo().alert().getText();
		String expectedData = "Please Fill In The First Name";
		assertEquals(expectedData, actualData);
		Thread.sleep(5000);
	}

	@When("^Clicking on Submit Button for last name validation$")
	public void clicking_on_Submit_Button_for_last_name_validation() {
		// Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		driver.findElement(firstName).sendKeys("Rutuja");
		driver.findElement(button).click();
	}

	@Then("^alert is coming 'please fill the last name'$")
	public void alert_is_coming_please_fill_the_last_name() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		String actualData =driver.switchTo().alert().getText();
		String expectedData = "Please Fill In The Last Name";
		assertEquals(expectedData, actualData);
		Thread.sleep(5000);
	}

	@When("^Clicking on Submit Button for email validation$")
	public void clicking_on_Submit_Button_for_email_validation() {
		// Write code here that turns the phrase above into concrete actions
		driver.switchTo().alert().dismiss();
		driver.findElement(firstName).sendKeys("Rutuja");
		driver.findElement(lastName).sendKeys("Choudhary");
		driver.findElement(button).click();
	}

	@Then("^alert is coming 'please fill the email'$")
	public void alert_is_coming_please_fill_the_email() throws InterruptedException {
		// Write code here that turns the phrase above into concrete actions
		String actualData =driver.switchTo().alert().getText();
		String expectedData = "Please Fill In The Email";
		assertEquals(expectedData, actualData);
		Thread.sleep(5000);
	}

	@When("^Clicking on Submit Button for mobile number validation$")
	public void clicking_on_Submit_Button_for_mobile_number_validation() {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^alert is coming 'please fill the mobile number'$")
	public void alert_is_coming_please_fill_the_mobile_number() {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Clicking on Submit Button for city validation$")
	public void clicking_on_Submit_Button_for_city_validation() {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^alert is coming 'please select the city'$")
	public void alert_is_coming_please_select_the_city() {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Clicking on Submit Button for state validation$")
	public void clicking_on_Submit_Button_for_state_validation() {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^alert is coming 'please select the state'$")
	public void alert_is_coming_please_select_the_state() {
		// Write code here that turns the phrase above into concrete actions

	}

	@When("^Clicking on Submit Button for Card Holder Name validation$")
	public void clicking_on_Submit_Button_for_Card_Holder_Name_validation() {
		// Write code here that turns the phrase above into concrete actions

	}

	@Then("^alert is coming 'please fill the Card Holder Name'$")
	public void alert_is_coming_please_fill_the_Card_Holder_Name() {
		// Write code here that turns the phrase above into concrete actions

	}

}
