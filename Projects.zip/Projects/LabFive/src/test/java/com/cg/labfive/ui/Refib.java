package com.cg.labfive.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Refib {

	int fib(int n) {
		if(n==1)
			return (1);
		else if(n==2)
			return (1);
		else
			return (fib(n-1)+fib(n-2));
	}
}
class RecFibDemo {
		InputStreamReader obj=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(obj);
		System.out.println("enter last number");
		int n=Integer.parseInt(br.readLine());
		Refib ob=new Refib();
		System.out.println("fibonacci series is as follows");
		int res=0;
		for(int i=1;i<=n;i++) {
			res=ob.fib(i);
			System.out.println(" "+res);
		}
		System.out.println();
		System.out.println(n+"th value of the series is "+res);
	}
}


int n;
int p;
Scanner s=new Scanner(System.in);
System.out.println("Enter a number: ");
n=s.nextInt();
for(int i=2;i<n;i++)
{
	p=0;
	for(int j=2;j<i;j++)
	{
		if(i%j==0)
		p=1;
	}
	if(p==0)
		System.out.println(i);
}