package com.cg.labfive.ui;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Scanner;

public class New {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scr=new Scanner(System.in);
		int i,a=0,b=1,c=0;
		System.out.println("Enter number:");
		int t=scr.nextInt();
		System.out.print(a);
		System.out.print(" "+b);
		for(i=0;i<t;i++) {
			c=a+b;
			a=b;
			b=c;
			System.out.print(" "+c);
		}
		System.out.println();
		System.out.print(t+"series is: "+c);
		
	}

}
