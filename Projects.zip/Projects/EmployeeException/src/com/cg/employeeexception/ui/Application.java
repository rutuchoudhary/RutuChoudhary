package com.cg.employeeexception.ui;

public class Application {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	
		try {
			new Info().getInfo(" ", "");
		} catch (EmployeeException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		
		
	
	}

}
