package com.cg.employeeexception.ui;

public class Info {

	public void getInfo(String Fname, String Lname) throws EmployeeException   {
		
		if(Fname == null && Lname== null) {
			
				throw new EmployeeException("Name Should not be blank");
		}
		System.out.println(Fname+Lname);
	}
}
