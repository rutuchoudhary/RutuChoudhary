package com.cg.labtwo.ui;

public abstract class Item {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
