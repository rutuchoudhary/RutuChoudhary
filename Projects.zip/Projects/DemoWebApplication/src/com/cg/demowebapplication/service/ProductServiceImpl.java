package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dao.ProductDaoImpl;
import com.cg.demowebapplication.dto.Product;

public class ProductServiceImpl implements ProductService {
	ProductDaoImpl dao; 

	public ProductServiceImpl() {
		dao = new ProductDaoImpl();
	}

	@Override
	public void addproduct(Product prod) {
		dao.saveproduct(prod);
	}

	@Override
	public List<Product> showProduct() {
		return dao.showAll();
	}

	@Override
	public Product searchById(int id) {
		return dao.findbyId(id);
	}

	@Override
	public Product updateProduct(Product prod) {
		return null;
	}

	@Override
	public void deleteProduct(Product prod) {
		dao.deleteProduct(prod);
	}




}
