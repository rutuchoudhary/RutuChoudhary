package com.cg.demowebapplication.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demowebapplication.dto.Product;

public class ProductDaoImpl implements ProductDao {

	List<Product> mylist = new LinkedList<>();

	@Override
	public void saveproduct(Product prod) {
		Product pro = findbyId(prod.getId());
		if(pro==null) {
		mylist.add(prod);
		}
		else {
			pro.setName(prod.getName());
			pro.setPrice(prod.getPrice());
			pro.setOnline(prod.getOnline());
			pro.setCategory(prod.getCategory());
		}
	}

	@Override
	public List<Product> showAll() {
		return mylist;
	}

	@Override
	public Product findbyId(int id) {
		for (Product p : mylist) {
			if (p.getId() == id) {
				return p;
			}
		}
		return null;
	}

	@Override
	public void deleteProduct(Product prod) {
		mylist.remove(prod);
	}
}
