package com.cg.primenumber.ui;

import java.util.Scanner;

public class Prime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int n, count;
		Scanner scr =new Scanner(System.in);
		System.out.println("Enter the number");
		n =scr.nextInt();
		for(int i=2; i<n; i++)
		{
			count=0;
			int cn=i;
			for(int j=2; j<cn;j++) {
				if(cn%j == 0)
					count++;	
			}
			if(count==0)
			{
				//System.out.println("Prime Number: ");
				System.out.println(cn);
			}
			
		}

	}

}
