package com.cg.democollectionone.ui;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;
import java.util.Scanner;

public class MainApplication {

	public static void main(String[] args) {
		Scanner scr = new Scanner(System.in);
		int emp_id = 0;
		String emp_name = null;
		double emp_salary = 0;
		PreparedStatement pstmt=null;
	/*	System.out.println("Enter Id");
		emp_id = scr.nextInt();
		System.out.println("Enter name");
		emp_name = scr.next();
		System.out.println("Enter Salary");
		emp_salary = scr.nextDouble();*/
		
		
		//Connection using properties
		String driver=null,url=null,uname=null,upass=null;
		try {
			InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
			Properties prop= new Properties();
			prop.load(it);
			driver=prop.getProperty("jdbc.driver");
			url=prop.getProperty("jdbc.url");
			uname=prop.getProperty("jdbc.username");
			upass=prop.getProperty("jdbc.password");


		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}







		try {
			Class.forName("com.mysql.jdbc.Driver");
			//Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "Capgemini123");
			Connection conn=DriverManager.getConnection(url,uname,upass);
			System.out.println("Connection done");
			
			//inserting data
			/* pstmt=conn.prepareStatement("INSERT INTO EMPLOYEE VALUES(?,?,?)");
			pstmt.setInt(1, emp_id);
			pstmt.setString(2, emp_name);
			pstmt.setDouble(3,emp_salary);
			int result=pstmt.executeUpdate();
			//getting result back using resultset		
			ResultSet rs = pstmt.executeQuery("SELECT * FROM EMPLOYEE");
			String format="%-4i%-8s%-8d%";
			while(rs.next()) {
				System.out.format(format, rs.getInt(1));
				System.out.format(format,rs.getString(2));
				System.out.format(format,rs.getDouble(3));
			}

			 */

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Driver not loaded");
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("connection not done");
		}
	}

}
