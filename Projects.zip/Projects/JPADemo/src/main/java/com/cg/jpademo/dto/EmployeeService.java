package com.cg.jpademo.dto;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class EmployeeService {
	
	public static void main(String[] args) {
	
	 EntityManagerFactory emf = Persistence.createEntityManagerFactory("demoemployeemanagement");
	 EntityManager em = emf.createEntityManager();																//loads persistence.xml
//	private EntityTransaction tx = em.getTransaction();
	em.getTransaction().begin();
	
	Address ad =new Address();
	ad.setCity("Pune");
	ad.setState("MH");
	ad.setPincode(452003);
	Address add=new Address("Mumbai","Maharashtra",425022);
	
	Department dept = new Department(1001,"Java");
	Department dep = new Department(1002,"Database");
	
	Employee emp = new Employee();
	emp.setId(1);
	emp.setName("Rutu");
	emp.setSalary(15726);
	emp.setType(true);
	emp.setDateofjoining(new Date());
	emp.setAddr(ad);
//	emp.setDept(dept);													\\not required for onetomany


//	Employee empp = new Employee(2,"Nishu", 10246.2,true,new Date(),add,dept);
//	Employee employee = new Employee(3,"Nikita",11134,true,new Date());
//	Employee empl = new Employee(4,"Kavi",21631,true,new Date());
	
	em.persist(emp);
	em.persist(dept);
//	em.persist(empp);
	/*em.persist(employee);
	em.persist(empl);*/
	
/*	Employee e = em.find(Employee.class, 101);				//to find
	System.out.println("Founded Employee: "+e);
	
	em.remove(e);															//to remove the founded id
	System.out.println(e+" Removed");
	
	
	Employee ee = em.find(Employee.class, 103);
	ee.setName("Rutu");
	System.out.println("After Updation: "+ee);*/
	em.getTransaction().commit();
	
	
	em.close();
	
	
	
	}
	
	

}
