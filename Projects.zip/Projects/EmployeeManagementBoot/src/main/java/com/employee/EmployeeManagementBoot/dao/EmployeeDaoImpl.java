package com.employee.EmployeeManagementBoot.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.employee.EmployeeManagementBoot.dto.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao {

	List<Employee> empList = new ArrayList<>();
	
	@Override
	public Employee saveEmployee(Employee emp) {
		empList.add(emp);
		return emp;
	}

	@Override
	public List<Employee> showAll() {
		return empList;
	}

	@Override
	public Employee findById(int id) {
		for(Employee e:empList) {
			if(e.getId()==id) {
				return e;
			}
		}
		return null;
	}

	@Override
	public void removeEmployee(Employee emp) {
		empList.remove(emp);

	}


}
