package com.employee.EmployeeManagementBoot.dao;

import java.util.List;

import com.employee.EmployeeManagementBoot.dto.Employee;

public interface EmployeeDao {
	public Employee saveEmployee(Employee emp);

	public List<Employee> showAll();

	public Employee findById(int id);
	
	public void removeEmployee(Employee emp);
	

}
