package com.employee.EmployeeManagementBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employee.EmployeeManagementBoot.dao.EmployeeDao;
import com.employee.EmployeeManagementBoot.dto.Employee;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDao empdao;

	@Override
	public Employee addEmployee(Employee emp) {
		return empdao.saveEmployee(emp);
	}

	@Override
	public List<Employee> showAll() {
		return empdao.showAll();
	}

	@Override
	public Employee searchById(int id) {
		return empdao.findById(id);
	}

	@Override
	public void deleteEmployee(Employee emp) {
		empdao.removeEmployee(emp);

	}

	@Override
	public Employee updateEmployee(Employee emp) {
		return emp;
	}

}
