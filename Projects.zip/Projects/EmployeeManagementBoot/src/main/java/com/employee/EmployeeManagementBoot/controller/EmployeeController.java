package com.employee.EmployeeManagementBoot.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.employee.EmployeeManagementBoot.dto.Employee;
import com.employee.EmployeeManagementBoot.service.EmployeeService;

@RestController
@RequestMapping("/employee")
public class EmployeeController {
	
	@Autowired
	EmployeeService empservice;
	
	
	@RequestMapping(value="/addemp", method=RequestMethod.POST)
	public Employee addEmployee(@RequestBody Employee emp) {
		return empservice.addEmployee(emp);
	}
	
	@RequestMapping(value="/showall",method=RequestMethod.GET)
	public List<Employee> showAllEmployee() {
		return empservice.showAll();
	}

	@RequestMapping(value="/searchemp",method=RequestMethod.POST)
	public Employee searchEmployee(@RequestBody Employee emp) {
		return empservice.searchById(emp.getId());
	}
	
	@RequestMapping(value="/deleteemp",method=RequestMethod.DELETE)
	public void deleteEmployee(@RequestBody Employee emp)  {
		Employee e = empservice.searchById(emp.getId());
		 empservice.deleteEmployee(e);
	}
	
	@RequestMapping(value="/modifyemp",method=RequestMethod.PUT)
	public Employee modifyEmployee(@RequestBody Employee emp) {
	Employee ee = empservice.searchById(emp.getId());
	ee.setName(emp.getName());
	ee.setSalary(emp.getSalary());
	empservice.updateEmployee(ee);
	return ee;
	}
	
	//Other Way
	@RequestMapping(value="/updateemp",method=RequestMethod.PUT)
	public Employee updateEmployee(@RequestParam("empid") int id, 
			@RequestParam("empname") String name, @RequestParam("empsalary") double salary) {
		Employee empone = empservice.searchById(id);
		empone.setName(name);
		empone.setSalary(salary);
		return empservice.updateEmployee(empone);
	}
}
