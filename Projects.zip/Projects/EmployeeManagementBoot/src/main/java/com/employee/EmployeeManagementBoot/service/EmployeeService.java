package com.employee.EmployeeManagementBoot.service;

import java.util.List;

import com.employee.EmployeeManagementBoot.dto.Employee;

public interface EmployeeService {
	
	public Employee addEmployee(Employee emp);

	public List<Employee> showAll();

	public Employee searchById(int id);
	
	public void deleteEmployee(Employee emp);
	
	public Employee updateEmployee(Employee emp);

}
