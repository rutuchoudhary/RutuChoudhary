package com.cg.democollection.dto;

public class Employee<T,K>{
	private T id;
	private String name;
	private K salary;
	
	public Employee() {

	}
	
	public Employee(T id, String name, K salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}


	public T getId() {
		return id;
	}

	public void setId(T id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public K getSalary() {
		return salary;
	}

	public void setSalary(K salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [id=" + id + ", name=" + name + ", salary=" + salary + "]";
	} 
	
	
	
	
	/*public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		if(this.getId()>o.getId() ) {
			return 1;
		}
		else if(this.getId()<o.getId()) {
			return -1;
		}
		
		return 0;									//if we remove the if statements and return 0 it will return only one value 
													//but if 1 is returned then in the order we have give 
													//but for -1 it will give in reverse of order given by us 
		
		
//		return this.getName().compareToIgnoreCase(o.getName());				//to compare string
*/	}

	
	
	


