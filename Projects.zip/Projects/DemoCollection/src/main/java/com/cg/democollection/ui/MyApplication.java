package com.cg.democollection.ui;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import com.cg.democollection.dto.Employee;
import com.cg.democollection.dto.EmployeeSorting;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	/*	Set<String> my = new TreeSet<String>();
		
		my.add("4");
		my.add("R");
		my.add("a");
		my.add("1");
		my.add("A");
		my.add("P");
		my.add("z");
		my.add(" ");
//		my.add(null);									//Null pointer exception

		System.out.println(my);							//this will sort in format of ASCII,UpperCase,LowerCase
		*/
		
//		System.out.println("Hi");
		
		
		Employee<Integer, Double> emp= new Employee<Integer, Double>(10,"rutu",1200.0);
		Employee<BigInteger, Double> emp1 = new Employee<BigInteger,Double>(new BigInteger("12"),"nish",1800.0 );
		Employee emp2 = new Employee(11,"rish",2400);
		
		List<Employee> myList = new ArrayList<Employee>();
		
		
		myList.add(emp);
		myList.add(emp1);
		myList.add(emp2);
		
		Collections.sort(myList, new EmployeeSorting());
		
		System.out.println(myList);
		
		
		
	}
}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*
		
		Set<String> myset = new TreeSet<String>();
		
		myset.add("R");
		myset.add("I");
		myset.add("T");
		myset.add("U");
		
		System.out.println(myset);
		
		Set<Employee> mySet = new HashSet<Employee>();
		
		
		Employee emp = new Employee(10,"rutu",1200);
		Employee emp1 = new Employee(12,"nish",1800);
		Employee emp2 = new Employee(11,"rish",2400);
		
		mySet.add(emp);
		mySet.add(emp1);
		mySet.add(emp2);
//		System.out.println(mySet);
		
		
		List<Employee> myList = new ArrayList<Employee>(mySet);
		Collections.sort(myList);
		
		for(Employee employee : myList) {
			System.out.println(employee.getName());
		}
//		Set<Employee> mySet = new TreeSet<Employee>();
		
		*/
		
	
		
	
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*Employee emp = new Employee(10,"Rutu",200);
		Employee emp1 = new Employee(10,"Rutu",200);
		Employee emp2 = new Employee(10,"Rutu",200);
		
		Set<Employee> mySet = new HashSet<Employee>();
		
		mySet.add(emp);
		mySet.add(emp1);
		mySet.add(emp2);
		
		
		System.out.println(mySet);*/
		

