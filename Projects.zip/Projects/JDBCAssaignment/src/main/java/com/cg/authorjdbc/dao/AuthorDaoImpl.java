package com.cg.authorjdbc.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.authorjdbc.dto.Author;
import com.cg.authorjdbc.exception.AuthorException;
import com.cg.authorjdbc.util.DBUtil;

public class AuthorDaoImpl implements AuthorDao {

	public Author save(Author author) throws AuthorException {
		Connection con = DBUtil.getConnection();
		String query_insert = "Insert into Author values(?,?,?,?,?)";
		PreparedStatement pstm = null;

		try {
			pstm = con.prepareStatement(query_insert);
			pstm.setInt(1, author.getId());
			pstm.setString(2, author.getFirstName());
			pstm.setString(3, author.getMiddleName());
			pstm.setString(4, author.getLastName());
			pstm.setString(5, author.getPhoneNo().toString());

			pstm.executeUpdate();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}

		return null;
	}

	public List<Author> showAll() throws SQLException {
		List<Author> authList = new ArrayList<Author>();

		Connection con;

		try {
			con = DBUtil.getConnection();

			String query_show = "select authorId,firstName,middleName,lastName,phoneNo from Author";
			PreparedStatement pstm;
			pstm = con.prepareStatement(query_show);
			ResultSet result = pstm.executeQuery();

			while (result.next()) {
				Author author = new Author();
				author.setId(result.getInt("authorId"));
				author.setFirstName(result.getString("firstName"));
				author.setMiddleName(result.getString("middleName"));
				author.setLastName(result.getString("lastName"));
				author.setPhoneNo(new BigInteger(result.getString("phoneNo")));

				authList.add(author);
			}
		} catch (AuthorException e) {
			e.printStackTrace();
		}
		return authList;
	}

	public Author update(int authorId) {
		return null;
	}

}
