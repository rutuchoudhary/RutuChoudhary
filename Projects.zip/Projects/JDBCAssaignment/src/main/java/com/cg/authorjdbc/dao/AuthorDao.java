package com.cg.authorjdbc.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.authorjdbc.dto.Author;
import com.cg.authorjdbc.exception.AuthorException;

public interface AuthorDao {
	public Author save(Author author) throws AuthorException;
	public List<Author> showAll() throws SQLException ;
	public Author update(int authorId);
}
