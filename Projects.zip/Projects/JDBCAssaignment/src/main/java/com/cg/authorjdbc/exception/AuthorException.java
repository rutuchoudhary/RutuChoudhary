package com.cg.authorjdbc.exception;

public class AuthorException extends Exception {
	public AuthorException() {
		super();
	}

	public AuthorException(String message) {
		super(message);
	}

}
