package com.cg.authorjdbc.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cg.authorjdbc.exception.AuthorException;

public class DBUtil {
	static Connection conn;
	
	public static Connection getConnection() throws AuthorException{
		Properties prop = new Properties();
		
		try {
			InputStream it = new FileInputStream("src/main/resources/jdbc.properties");
			prop.load(it);
			
			if(prop != null) {
				
				String driver = prop.getProperty("jdbc.Driver");
				String url = prop.getProperty("jdbc.url");
				String uname = prop.getProperty("jdbc.username");
				String upass = prop.getProperty("jdbc.password");
				conn = DriverManager.getConnection(url, uname, upass);
				
			}	
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new AuthorException("File not found");
		} catch (IOException e) {
			e.printStackTrace();
			throw new AuthorException("File not open");
		} catch (SQLException e) {
			e.printStackTrace();
			new AuthorException("Connection not established");
		}
		return conn;
	}
	
}
