package com.cg.authorjdbc.ui;

import java.math.BigInteger;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.cg.authorjdbc.dto.Author;
import com.cg.authorjdbc.exception.AuthorException;
import com.cg.authorjdbc.service.AuthorServiceImpl;

public class MyApplication {
	
	public static void main(String[] args) throws SQLException {
		Scanner sc = new Scanner(System.in);
		int choice=0;
		AuthorServiceImpl service = new AuthorServiceImpl();
		
		do {
			System.out.println("Enter your choice:");
			System.out.println("1.Add Author");
			System.out.println("2.Show Author Details");
			System.out.println("3.Update Author");
			
			choice = sc.nextInt();
			
			switch(choice) {
			case 1:
				System.out.println("Enter Author Id");
				int a_id = sc.nextInt();
				System.out.println("Enter Author's FirstName");
				String f_name = sc.next();
				System.out.println("Enter Author's MiddleName");
				String m_name = sc.next();
				System.out.println("Enter Author's LastName");
				String l_name = sc.next();
				System.out.println("Enter Author's Mobile Number");
				BigInteger phone_no = sc.nextBigInteger();
				
				Author auth = new Author();
				auth.setId(a_id);
				auth.setFirstName(f_name);
				auth.setMiddleName(m_name);
				auth.setLastName(l_name);
				auth.setPhoneNo(phone_no);
				
				try {
					service.add(auth);
				} catch (AuthorException e) {
					e.printStackTrace();
				}
				
				break;
				
			case 2:
				List<Author> myList = service.showAll();
				for(Author authordata : myList) {
					System.out.println("Author Id is"+authordata.getId());
					System.out.println("Author FirstName is"+authordata.getFirstName());
					System.out.println("Author MiddleName is"+authordata.getMiddleName());
					System.out.println("Author LastName is"+authordata.getLastName());
					System.out.println("Author PhoneNo is"+authordata.getPhoneNo());
				}
				break;
			}
			
		}while(choice!=0);

	}

}
