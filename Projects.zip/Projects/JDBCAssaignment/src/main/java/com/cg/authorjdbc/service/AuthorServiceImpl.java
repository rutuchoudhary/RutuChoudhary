package com.cg.authorjdbc.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.authorjdbc.dao.AuthorDaoImpl;
import com.cg.authorjdbc.dto.Author;
import com.cg.authorjdbc.exception.AuthorException;

public class AuthorServiceImpl implements AuthorService {

	AuthorDaoImpl dao = new AuthorDaoImpl();

	public Author add(Author author) throws AuthorException {
		return dao.save(author);
	}

	public List<Author> showAll() throws SQLException {
		return dao.showAll();
	}

	public Author update(int authorId) {
		return null;
	}

}
