package com.cg.thread.dto;

public class Odd implements Runnable{
	int i=0;
	
	
	/*
	
	public Odd(int i) {
		super();
		this.i = i;
	}
*/

	public void run() {
		// TODO Auto-generated method stub
		for(i=0;i<15;i++) {
		if(i%2!=0) {
			System.out.println("Number is Odd"+i);
		}
		}
	}

}
