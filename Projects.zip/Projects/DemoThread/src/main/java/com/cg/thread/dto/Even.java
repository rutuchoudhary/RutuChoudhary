package com.cg.thread.dto;

public class Even implements Runnable {
	int i=0;
	
	public void run() {
		// TODO Auto-generated method stub
		for(i=0;i<10;i++) {
		if(i%2==0) {
			System.out.println("Number is Even"+i);
		}
		}
	}

}
