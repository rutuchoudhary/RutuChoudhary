package com.cg.thread.ui;

import java.util.Scanner;

import com.cg.thread.dto.Even;
import com.cg.thread.dto.Odd;

public class TestClass
{
	public static void main(String args[]) throws Exception
	{
		Incrementor i = new Incrementor();
		Decrementor d = new Decrementor();
		i.start();
		d.start();
	}
}
	class Base extends Thread
	{
		static int k = 10;
	}
	class Incrementor extends Base
	{
		public void run()
		{
			for(; k>0; k++)
			{
				System.out.println("IRunning...");
			}
		}
	}
	class Decrementor extends Base
	{
		public void run()
		{
			for(; k>0; k--)
			{
				System.out.println("DRunning...");
			}
		}
	}


	/*public void run() {
		// TODO Auto-generated method stub
//		System.out.println(" ");
	}*/

		
		
		
		
		
		
		
		
		
		
		


		
		
		
		
		
		
		
		
		
		
		
		
		
	
	/*System.out.println("We are in "+Thread.currentThread().getName());
		
	NewThread nt=new NewThread();
	Thread t = new Thread(nt);
	Thread tone = new Thread(nt);
	Thread ttwo = new Thread(nt);
	
	t.setName("Rutu");
	tone.setName("Nishu");
	ttwo.setName("Both");
	t.start();
	tone.start();
	ttwo.start();
//	t.start();									//if we start the same thread instance repeatedly throws exception IllegalThreadStateException
	}

	public void run() {
//		int count=1;
		// TODO Auto-generated method stub
		for(int i=0;i<=5;i++ ) {
//		count++;
//		System.out.println("Hi Nishu");
		
		System.out.println("Hey "+Thread.currentThread().getName()+" "+i);
		System.out.println("Id is "+Thread.currentThread().getId());
		System.out.println("Group is "+Thread.currentThread().getThreadGroup());
//		System.out.println(count);
		}
		
	}
	*/
	/*public void run(String s) {								//can not override the method
		for(int i=0;i<=5;i++ ) {
		System.out.println("Overridden Method"+s);
		}
	}*/






/*  Using Extend
 public class NewThread extends Thread{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		NewThread nt = new NewThread();
		nt.start();
		
		new NewThread().start();
	}


	public void run(){
		System.out.println("Hello ..  Welcome to Capgemini.");
		}

	}*/

