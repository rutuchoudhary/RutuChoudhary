package com.cg.demoonespringcore.ui;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.demoonespringcore.config.JavaConfig;
import com.cg.demoonespringcore.dto.Product;
import com.cg.demoonespringcore.dto.Tranaction;
import com.cg.demoonespringcore.service.ProductService;

@Component
public class MyTest {
	@Autowired
	ProductService service;
	
	static ProductService productService;
	
	@PostConstruct
	public void init() {
		productService = this.service;
	}

	public static void main(String[] args) {
		AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);			//object creating here

		Product myProduct = (Product) app.getBean("prod");
		Tranaction myTransaction = (Tranaction) app.getBean("tran");

//		ProductService service = (ProductService) app.getBean("productService");			//alternate solution to get data, for this no need to write the @Autowired and static above main method

		myProduct.setId(101);
		myProduct.setName("Product");
		myProduct.setPrice(1234.5);
		myProduct.setDescription("Random Product");

		myTransaction.setId(1);
		myTransaction.setAmount(2345);
		myTransaction.setDescription("For Listed Product");

		productService.addProduct(myProduct);

		System.out.println(productService.showAllProduct());
	}

}
