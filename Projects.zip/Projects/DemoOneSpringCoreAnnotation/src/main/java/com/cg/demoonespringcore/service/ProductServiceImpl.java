package com.cg.demoonespringcore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demoonespringcore.dao.ProductDaoImpl;
import com.cg.demoonespringcore.dto.Product;

@Service("productService")
public class ProductServiceImpl implements ProductService {
	@Autowired
	ProductDaoImpl dao;

	public void addProduct(Product prod) {
		dao.saveProduct(prod);
	}

	public List<Product> showAllProduct() {
		return dao.showAllProduct();
	}

}
