package com.cg.productmanagement.dao;

import java.util.List;

import com.cg.productmanagement.dto.Product;

public interface IProductDao {
	
	public Product save(Product prod);
	public List<Product> findBy(int id);
	

}
