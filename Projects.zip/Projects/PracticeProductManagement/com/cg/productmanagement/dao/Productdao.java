package com.cg.productmanagement.dao;

public class Productdao {

}
