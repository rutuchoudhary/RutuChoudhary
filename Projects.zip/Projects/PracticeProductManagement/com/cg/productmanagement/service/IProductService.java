package com.cg.productmanagement.service;

public interface IProductService {

}
