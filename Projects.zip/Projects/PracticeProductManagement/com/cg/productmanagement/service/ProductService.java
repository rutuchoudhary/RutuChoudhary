package com.cg.productmanagement.service;

import com.cg.productmanagement.dao.IProductDao;

public class ProductService implements IProductService {

	IProductDao dao;
	
	public ProductService() {
		
	}
}
