package com.cg.productmanagement.dao;

import java.util.List;

import com.cg.productmanagement.dto.Product;

public interface ProductDao {
	
	public Product addProduct(Product product);
	public List<Product> getAll();
	public List<Product> findByPrice(double min, double max);
	public Product findById(int id);
	public String remove(int id);

}
