package com.cg.productmanagement;

import java.util.List;
import java.util.Scanner;

import com.cg.productmanagement.dto.Product;
import com.cg.productmanagement.service.ProductService;
import com.cg.productmanagement.service.ProductServiceImpl;

public class MyApplication {

	public static void main(String[] args) {
		ProductService service = new ProductServiceImpl();
		Product pro=null;
		int choice =0;
		do {
			
			System.out.println("1.Add 2.Show 3.Searchbyprice 4.Searchbyid 5.Remove 6.Update 7.Sort" );
			
			Scanner scr = new Scanner(System.in);
			choice = scr.nextInt();
			
		switch (choice) {
		case 1:
			System.out.println("Enter Id");
			int id = scr.nextInt();
			System.out.println("Enter Name");
			String name = scr.next();
			System.out.println("Enter price");
			double price = scr.nextDouble();
			System.out.println("Enter description");
			String description = scr.next();
			/*pro.setId(id);
			pro.setName(name);
			pro.setPrice(price);
			pro.setDescription(description);
			*/
			pro=new Product(id,name,price,description);
			service.addProduct(pro);
			
			break;
			
		case 2:
			List<Product> products=service.showAll();
			for(Product p: products) {
				System.out.println(p);
			}
			break;

		case 3:
			System.out.println("Enter Min price: ");
			double min = scr.nextDouble();
			System.out.println("Enter Max price: ");
			double max =scr.nextDouble();
			List<Product> prods=service.searchByPrice(min, max);
			for(Product p : prods) {
				System.out.println(p);
			}
			break;
			
		case 4:
			System.out.println("Enter Id: ");
			int i = scr.nextInt();
			Product prod = service.searchById(i);
			if(prod != null) {
				System.out.println(prod);
			}
			else {
				System.out.println("Not found");
			}
			break;
			
		case 5:
			
//			service.remove();
			System.out.println("product removed");
			break;
			
			
		default:
			break;
		}
		}while(choice <8);

	}

}

/*
Exception in thread "main" java.util.ConcurrentModificationException
at java.util.ArrayList$Itr.checkForComodification(ArrayList.java:901)
at java.util.ArrayList$Itr.next(ArrayList.java:851)
at com.cg.productmanagement.dao.ProductDaoImpl.findById(ProductDaoImpl.java:41)
at com.cg.productmanagement.service.ProductServiceImpl.searchById(ProductServiceImpl.java:33)
at com.cg.productmanagement.MyApplication.main(MyApplication.java:64)
*/