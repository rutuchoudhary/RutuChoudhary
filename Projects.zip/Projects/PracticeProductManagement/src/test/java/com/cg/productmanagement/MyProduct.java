package com.cg.productmanagement;

public class MyProduct {

	public static void main(String[] args) {

	}

}
