package com.cg.productmanagement.service;

import java.util.List;

import com.cg.productmanagement.dao.ProductDao;
import com.cg.productmanagement.dao.ProductDaoImpl;
import com.cg.productmanagement.dto.Product;

public class ProductServiceImpl implements ProductService {

	ProductDao dao;
	
	public ProductServiceImpl() {
		dao = new ProductDaoImpl();
	}

	public Product addProduct(Product product) {
		return dao.addProduct(product);
	}

	public List<Product> showAll() {

		return dao.getAll();
	}

	public List<Product> searchByPrice(double min, double max) {

		return dao.findByPrice(min, max);
	}

	public Product searchById(int id) {

		return dao.findById(id);
	}

	public String remove(int id) {

		return null;
	}

	public Product update(int id) {

		return null;
	}
	

}
