package com.cg.productmanagement.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.productmanagement.dto.Product;

public class ProductDaoImpl implements ProductDao{

	List<Product> prod;
	
	public ProductDaoImpl() {
		prod = new ArrayList<Product>();
	}

	public Product addProduct(Product product) {
		prod.add(product);
		return product ;
		
	}

	public List<Product> getAll() {

		return prod;
	}

	public List<Product> findByPrice(double min, double max) {

		List<Product> products = new ArrayList<Product>();
		for(Product p: prod) {
			if(p.getPrice()>=min && p.getPrice()<=max) {
			products.add(p);
			}
		}
	
		return products;
	}

	public Product findById(int id) {
		for(Product p: prod) {
			if(p.getId()==id) {
				return p;
			}
		}
		return null;
	}

	
	public String remove(int id) {

		prod.remove(prod);
		return null;
	}

}
