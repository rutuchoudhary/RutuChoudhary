package com.cg.productmanagement.service;

import java.util.List;

import com.cg.productmanagement.dto.Product;

public interface ProductService {
	
	public Product addProduct(Product product);
	public List<Product> showAll();
	public List<Product> searchByPrice(double min, double max);
	public Product searchById(int id);
	public String remove(int id);
	public Product update(int id);
	
}
