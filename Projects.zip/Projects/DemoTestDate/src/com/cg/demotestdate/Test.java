package com.cg.demotestdate;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		LocalDate localDate = LocalDate.now();
		System.out.println(localDate.getDayOfMonth());
		System.out.println(localDate.isLeapYear());
		System.out.println(localDate.plusDays(1));
		LocalDateTime localDateTIme = LocalDateTime.now();
		System.out.println(localDateTIme);
//		String str = new String("");
		
		ZonedDateTime zone = ZonedDateTime.now();
		System.out.println(zone);
		ZonedDateTime zoneanother = ZonedDateTime.now(ZoneId.of("Europe/Paris"));
		System.out.println(zoneanother);
		ZonedDateTime z = ZonedDateTime.now();
		
		
	}

}
