package com.cg.demotestcollection.ui;


import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee emp = new Employee(10,"C");
		Employee empp = new Employee(20,"R");
//		emp=empp;
		empp=emp;
		System.out.println(emp.id);
		
		System.out.println(emp.hashCode());
		System.out.println(empp.hashCode());
		System.out.println(emp.equals(empp));
	}

}
	
class Employee {
	
	int id;
	String Name;
	
	public Employee() {
		
	}
	
	public Employee(int id, String name) {
		super();
		this.id = id;
		Name = name;
	}


}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		/*List myList=new LinkedList();
		myList.add("RR");
		myList.add(1);
		System.out.println(myList);
		List<String> myListOne = new LinkedList<String>();						//we can write only class in <>String,Integer or Employee like
		
		myListOne.add("C");
		myListOne.add("R");
		myListOne.add("R");
		System.out.println(myListOne);
			
		for(String list:myListOne) {												//another way to print 
			System.out.println(list);
		}
		
		System.out.println("____________________________________________");
		
		Iterator<String> it = myListOne.iterator();
		while(it.hasNext()) {
//			it.remove();
			System.out.println(it.next());
		}*/
	