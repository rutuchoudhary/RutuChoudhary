package com.cg.demoinheritance.ui;

public class Mytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A temp =(A)new B();
		((A)temp).getAll();
		System.out.println(temp.a);					//value 10 printed because we are not overriding the variable.
		
		
	}
}
		
		class B {
			static int a=10;
			public void getAll() {
				System.out.println("In B");
			}
		}
		class A extends B {
			int a=20;
			public void getAll() {
				System.out.println("In A");
			}
		}
		
		//Overloading same methods diff parameter
		/*
		new A().getAll(20);
	}
}
		
		class B {
			
		}
	class A {
		public void getAll() {
			System.out.println("Hii Get all");
		}
		public double getAll(int a) {
			System.out.println("Hii Get all  " +a);
			return 1.0;
		}
	}
		
		*/
		
		
		//Practice
//		new C(10);
//	}
//}
//	 class A {
//			public A() {
//				System.out.println("In A");
//			}
//		}
//		 class B extends A {
//			 public B() {
//				 System.out.println("In B");
//			 }
//		 }
//		 class C extends B {
//			 int empId;
//			 public C() {
//				 System.out.println("In c");
//			 }
//			 public C(int i) {
//				 this.empId=i;
//				 System.out.println(empId);
//			 }
//		 }
		/*
		B temp = new B();
		System.out.println(temp.a);
		temp.getAll();
	}

}
class A {
	int a=20;
	public A() {
		System.out.println("In a class As");
	}
	public void getAll() {
		System.out.println("In class a method");
	}
}		//End of class A

class B extends A {
	public B() {
		super();						// not necessary to write this, compiler automatically writes it.
		System.out.println("In class B");
	}
	*/

