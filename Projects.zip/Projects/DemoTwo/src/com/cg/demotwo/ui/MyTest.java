package com.cg.demotwo.ui;

import java.math.BigDecimal;

import com.cg.demotwo.dto.Employee;
//import com.cg.demotwo.ui.A.B;

public class MyTest {
	
	//static double salary=1000;					s
	
	
	public static void main(String[] args) {
		
		Timing temp= new DayShift();				//Run Time Polymorphism
		temp.login();
		temp.logOut();
		temp.getComapny();
		System.out.println(temp.timing);
		
	}
		
		
	}
////		B temp= new A().new B();					//for inner class only
//		A.B temp = new A.B();
//		temp.getAll();
//		
//		A demo = new A();
//		demo.getA();
//		
//	
//	}
//}
//class A{
//	private int a=10;
////	class  {
//	static class B {																		//static class for 
//		int b=20;
//		public void getAll() {
//			System.out.println("In class B: "+b);
//		}
//	}
//	public void getA() {
//		// TODO Auto-generated method stub
//		System.out.println("In class A: "+a);
//	}
//}
//

	/*													///Static Block
		System.out.println("In Main..");
		new A();
		new A();
//		A.getAll();
	}
	static {
		System.out.println("Hi In Static Block...");
	}
}

class A {
	static {
		System.out.println("In A Static Block");
	}

	public A() {
		System.out.println("In A...");
	}
	public static void getAll() {
		// TODO Auto-generated method stub
		System.out.println("In Static Method..");
	}
	
}
		// TODO Auto-generated method stub
		
//		System.out.println(salary);
//		getAllData();
 
 
 */
		
/*		
		A aone = new A();
		A atwo = new A();
		A athree= new A();
		
		aone.data=30;
		aone.temp=10;
		A.getAll(athree);
		System.out.println(atwo.temp);
		System.out.println(atwo.data);
	}
}

	class A{
	int data =10;
	static int temp=20;
	public A() {
		System.out.println("In A");
	}
			public static void getAll(A a) {
//				A h= new A();
				a.data=50;
				a.temp=80;
				System.out.println("In method");
//				h.data=id;
			}
		}
	
	
	*/					//static
	
	
	
	
	
	
//		static void getAllData() {
//			//Static
//			System.out.println("Static... ");
//		}
//		 void getData() {
//			//nonStatic
//			 getData();
//			System.out.println("Non Static...");
//		}
//		
		
		
		
//		Employee.pf=1200;
//		Employee emp = new Employee(101, "Rutu ", new BigDecimal(10000),0.1);
//		
//		System.out.println("Employee Id is: "+emp.getEmpId());
//		System.out.println("Employee salary is: "+emp.takeHomeSalary());
//		System.out.println("Employee Name Is: "+emp.getFullname());
//	
//		System.out.println("PF is: "+Employee.pf);
//	
//		Employee empone = new Employee(102,"Nishu ", new BigDecimal(10001),0.2);					//We need to pass particlar variable
//		
//		System.out.println("Employee Id is: "+empone.getEmpId());
//		System.out.println("Employee salary is: "+empone.takeHomeSalary());
//		System.out.println("Employee Name Is: "+empone.getFullname());
//	
	
	
	


