package com.cg.demotwo.ui;

public class DayShift extends Timing {

	@Override
	public void login() {
		// TODO Auto-generated method stub
		System.out.println("Logged IN");
		
	}

	@Override
	public double logOut() {
		// TODO Auto-generated method stub
		return 12.4;
	}

}
