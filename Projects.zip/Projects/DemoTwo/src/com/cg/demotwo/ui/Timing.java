package com.cg.demotwo.ui;

public abstract class Timing {

	double timing = 9.5;
	public abstract void login();
	public abstract double logOut();
	public String getComapny()
	{
		return "Capgemini";
	}
	
}
