package com.cg.practice.calcengine;

public class Main {

	public static void main(String[] args) {
//		 TODO Auto-generated method stub
		int[] val = {10,20};
		int[] val1 = {10,9};
		char[] opcodes = {'a','b'};
		int result[] = new int[opcodes.length]; 
		
		
		 {	
			MathEquation[] equation = new MathEquation[2];
			equation[0] = create(10,20,'a');
			equation[1] = create(10,9,'b');
			
			for(MathEquation equation1 : equation) {
				equation1.Execute();			
				System.out.println("result is : "+equation1.result );
			}
			
			
//			switch(opcodes[i]) {
//			case 'a' :
//				result[i] = val[i] + val1[i];
//				break;
//			case 'b':
//				result[i] = val[i] * val1[i];
//				break;
//			default :
//				System.out.println("Error");
//			    result[i] = 0;
//			    break;
//			
//		}
		}
		
	}	
	
	public static MathEquation create(int val, int val1, char opcodes) {
		MathEquation equation = new MathEquation();
		equation.val=val;
		equation.val1=val1;
		equation.opcodes=opcodes;
		
		return equation;
	}
		
		
		
		/*
//		
//		int i = 7 | 2;
//		int j = 7 & 2;
//		
		int a = 10;
		String name ="RC";
		char aa='d';
		
//		if((a++==11)||(--a>11 || ++a==11)) {
//			System.out.println("true"+a);
//		} else {
//				System.out.println("false"+a);
//			}
//		
//		System.out.println("i is:"  +i + " j is:"+ j);
 
 */
	
		
		
		 
		
		
		
		
	/*
		int val = 10;
		int val1 = 13;
		int result= 0 ;
		char opcode = 'b';
		int factorial = 1;
		int i=1;
		while(i <=val) {
			factorial *= i;
			i++;
//		result = result + Fact;
		}
		if(opcode == 'a')
			result = val + val1;
		else if(opcode == 'b')
			result = val*val1;
	
	
		System.out.println("factorial is : " );
	}
	*/

}
