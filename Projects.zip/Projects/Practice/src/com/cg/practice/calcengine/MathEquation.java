package com.cg.practice.calcengine;

public class MathEquation {
	
	public int val;
	public int val1;
	public char opcodes;
	public int result;
	
	
	public void Execute() {
		switch(opcodes) {
		case 'a' :
			result = val + val1;
			break;
		case 'b':
			result = val * val1;
			break;
		default :
			System.out.println("Error");
		    result = 0;
		    break;
		
	}
	}
	

}
