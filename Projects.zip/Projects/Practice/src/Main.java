import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class Main {

	public static void main(String[] args) {
		
		BufferedReader reader = null;
		int total =0;
		
		
		try {
			reader = new BufferedReader(new FileReader("c:\\Numbers.txt"));
			String line = null;
			
			while((line = reader.readLine())!= null)
			{
				total +=Integer.valueOf(line);
			}
			System.out.println("Total: "+total);
		}
//		catch (Exception e) {
//			// TODO Auto-generated catch block
//			System.out.println("Error Message"+e.getMessage());
////			e.printStackTrace();
//		}
		catch(NumberFormatException e) {
			System.out.println("Invalid Issue:" + e.getMessage());
		}
		catch (FileNotFoundException e) {
			System.out.println("File Not Found" +e.getMessage());
		}
		catch (IOException e) {
			System.out.println("Error" +e.getMessage());
		}
		finally {
			if(reader != null)
				try {
					reader.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
		}
		
	}
}
		


		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		int intval = 10;
//		float floatval = 0.1f;
//		double doubleval = 23d;
//		byte byteval = 1;
//		short shortval = 4;
//		long longval = 5;
//		
//
//		short result = byteval;
//		float result1 = intval;
//		//int result2 = floatval;		Type mismatch: cannot convert from float to int
//		int result2 = (int)floatval;
//		double result3 = floatval;
//		
//		//byte resultA = intval - doubleval;		Type mismatch: cannot convert from double to byte
//		byte resultA = (byte) (intval - doubleval);
//		//long resultB = shortval - longval + floatval * doubleval;	Type mismatch: cannot convert from double to long
//		long resultB = shortval - longval + (long) floatval * (long)doubleval;
//		
//		System.out.println("printed");
//	}
		
		
	/*
		String name="Hi";
				name += " Rutu Gud Mrng";
		String name1 = "Hi Rutu";
		name1 += " Gud Mrng";
		System.out.println(name);
		System.out.println(name1);
		if(name.equals(name1)) {
			System.out.println("All is well");
		}
		String name2= name1.intern();
		System.out.println(name2);
		*/
		
		
		
		
//		Flight fgt =new Flight();
//		fgt.add();
//		fgt.handleAll();
//		fgt.remove(10, 5);
		
		
		
		
