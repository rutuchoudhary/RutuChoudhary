
public class Flight {
	 Integer flightnumber=10;
	 String flightname="Abc";
	 
	 
	@Override
	public String toString() {
		if(flightnumber != null)
		{
			return "Flight # " +flightnumber;
		}
			else {
				System.out.println("Flight Is");
				return flightname;
			}
		}
	}
	 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*
	int passengers = 4;
	int seats = 5;
	int checkedbags;
	int maxcarryons= seats*2;
	int totalcarryons;
	
	Flight() {
		System.out.println("In Flight");
	}
	

	public void add() {
			 if (hasSeating()) {
			passengers += 1;
		System.out.println(passengers);
		}
		else {
			handleAll();
		}
	}
	
	private boolean hasSeating() {
		return passengers < seats;
	}
	
	private boolean hasMaxCarryOns(int carryons) {
		return totalcarryons + carryons <= maxcarryons;
	}
	
	
	
		void handleAll() {
			System.out.println("Seats allocated : " +seats );
		}
		
		void remove(int passengers, int seats) {
			while(passengers >= seats) {
				passengers -=1;
			}
			System.out.println(passengers);
			}
		
}
*/