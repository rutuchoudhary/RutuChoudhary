
public class Student {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int myId=17;
		
		/*
		myId -= 4;
		System.out.println(myId);
		System.out.println(++myId);
		
		*/
		  int otherId = 1762;
		
		/*
		myId=otherId;
		
		System.out.println(myId);
		
		int anotherId = 176295;
		System.out.println(anotherId++);
		
		System.out.println(anotherId);
	*/
		  
		  //int bigId = myId < otherId ? otherId : myId; 
		  int bigId = myId == otherId ? 100 : otherId/myId;
		  
		  System.out.println(bigId);
	}

}
