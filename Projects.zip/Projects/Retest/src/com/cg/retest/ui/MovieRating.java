package com.cg.retest.ui;

import java.util.Comparator;

public class MovieRating implements Comparator<Movie> {
	
	public int compare(Movie o1, Movie o2) {
		if(o1.getRating() < o2.getRating())
			return -1;
		if(o1.getRating() > o2.getRating())
			return 1;
		else
		return 0;
	}

}
