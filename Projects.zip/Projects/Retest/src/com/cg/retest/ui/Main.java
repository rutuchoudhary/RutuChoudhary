package com.cg.retest.ui;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		 int arr[ ] = new int[2];  
	     System.out.println(arr[0]);
	     System.out.println(arr[1]);
		
		Movie m=new Movie();
		m.setName("Raaz");
		m.setRating(8);
		m.setYear(2000);
		ArrayList<Movie> myList= new ArrayList<Movie>();
		
		myList.add(new Movie("Zero",9,2018));
		myList.add(m);
		myList.add(new Movie("Baby",7,2018));
		myList.add(new Movie("Boss",10,2015));
		
		
			System.out.println("Sort by rating");
			MovieRating mr = new MovieRating();
			Collections.sort(myList,mr);
			for(Movie movrat: myList) {
				System.out.println(movrat.getName()+" "+movrat.getRating()+" "+movrat.getYear());
//				System.out.println(Collections.binarySearch(myList, mr));
			}
			System.out.println("\n");
				Collections.sort(myList); 
				System.out.println("After sort by year");
				for(Movie movie : myList) {
					System.out.println(movie.getName()+" "+movie.getRating()+" "+movie.getYear());
			}
		
	}

}
