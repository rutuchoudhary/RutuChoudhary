package com.cg.retest.ui;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
	public class Tire {
		   public static void main( String args[] )throws InterruptedException {
			   Thread t = new Thread();
			   t.start();
			   System.out.print("X");
			   synchronized (t) 
			   {
			    t.wait(10000);
			   }
			   
			   System.out.print("Y");
		}
	}
			 