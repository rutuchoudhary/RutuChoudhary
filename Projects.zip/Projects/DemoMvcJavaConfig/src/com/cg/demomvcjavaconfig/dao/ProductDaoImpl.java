package com.cg.demomvcjavaconfig.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Product;
import com.cg.demomvcjavaconfig.dto.Transaction;

@Repository
public class ProductDaoImpl implements ProductDao {

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public Product saveProduct(Product pro) {
		Product proOne = getProduct(pro.getId());
		if(proOne==null) {
		entitymanager.persist(pro);
		entitymanager.flush();
		} else {
			Transaction tran = new Transaction();
			tran.setId(pro.getTran().get(0).getId());
			tran.setPro(proOne);
			entitymanager.persist(tran);
			entitymanager.flush();
		}
		return pro;
	}

	@Override
	public List<Product> showAllProduct() {
		Query query=entitymanager.createQuery("from product");
		List<Product> myList = query.getResultList();
		return myList;
	}
	
	public Product getProduct(Integer prodid) {
		Product prod=null;
		try {
		Query q= entitymanager.createQuery("from Product where id=:prodid");
		q.setParameter("prodid",prodid);
		 prod = (Product) q.getSingleResult();
		}catch(NoResultException e) {
			System.out.println("No Id Found");
		}
		return prod;
	}

}
