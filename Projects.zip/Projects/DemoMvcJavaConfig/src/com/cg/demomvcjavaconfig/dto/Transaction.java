package com.cg.demomvcjavaconfig.dto;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ProductTranaction")
public class Transaction {
	@Id
	private Integer id;
	@ManyToOne
	@JoinColumn(name = "prod_tran")
	private Product pro;

	public Transaction() {
	}

	public Transaction(Integer id, Product pro) {
		super();
		this.id = id;
		this.pro = pro;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Product getPro() {
		return pro;
	}

	public void setPro(Product pro) {
		this.pro = pro;
	}

	@Override
	public String toString() {
		return "Transaction [id=" + id + ", pro=" + pro + "]";
	}

	
}
