package com.cg.demomvcjavaconfig.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demomvcjavaconfig.dao.ProductDao;
import com.cg.demomvcjavaconfig.dto.Product;

@Service
@Transactional
public class ProductserviceImpl implements ProductService{

	@Autowired
	ProductDao dao;
	@Override
	public Product addProduct(Product pro) {
		return dao.saveProduct(pro);
	}

	@Override
	public List<Product> showAllProduct() {
		return dao.showAllProduct();
	}

}
