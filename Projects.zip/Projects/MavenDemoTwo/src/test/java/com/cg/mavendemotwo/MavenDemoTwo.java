package com.cg.mavendemotwo;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class MavenDemoTwo {

	@Before
	public void before() {
		System.out.println("Before Tests");
	}
	
	@Test
	public void test() {
		System.out.println("In Test");
	}

	@After
	public void after() {
		System.out.println("After Test");
	}
}
