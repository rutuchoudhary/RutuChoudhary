package com.cg.demoexception.ui;

import java.io.IOException;

public class B {

	public void getAll(int salary) { 
	
			if(salary<=5000) {
			throw new EmployeeException("Salary Should be greater than 5000");
		}
		System.out.println(salary);
}
 
		
		
		
		
		
//		throws IOException  {
//	int a =10;
//	int b=0;
//	if(b==0) {
//		throw new IOException("B should be greater than zero");
//	}
//	System.out.println(a/b);
//	
//	

		
		
		
		/*
		int a =10;
		int b=0;
		int c[] = {10,22,33};
		try {
			System.out.println(a/b);				//only one condition will be checked in try block if both conditions having exception it will not check the other one. 
			System.out.println(c[9]);				//Hence only one exception will be handled.
		}
		
		catch(ArithmeticException e) {
			System.out.println("Check number");
		}catch (ArrayIndexOutOfBoundsException e) {
			System.out.println("Check array");
		}
		catch(Exception e) {
			System.out.println("In Exception");					//We can not write Exception after try, it will give error, because that is the super class handled in the last only but before finally
		}
		finally {
			System.out.println("Always");
		}
		System.out.println("Hi");
		
	}
		
		*/
		
		
		
		/*
		int a[] = {10,20,30};
		try {
//			System.out.println(a[3]);					//Exception because arrayindexoutofBound
//			System.out.println(a[1]);					//will give value at 1st index
			System.out.println(a[6]);
		}catch(NullPointerException e) {					
				System.out.println("Check Array");
			}
//		catch(ArrayIndexOutOfBoundsException e) {			//if we are handling exception in multiple catch statement we can write like this... 
//				System.out.println("Object not found");			//.....But, we can throw this exception without using multiple catch.
//			}
		
		finally {											//always executes exception is there or not. 
				System.out.println("Always");
			}
				
		System.out.println("In B");
	}
	*/
	
}



