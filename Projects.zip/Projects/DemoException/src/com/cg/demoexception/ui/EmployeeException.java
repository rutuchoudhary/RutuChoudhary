package com.cg.demoexception.ui;

public class EmployeeException extends RuntimeException{	//User defined exception cab be extended in two ways either Exception or RuntimeException 

	public EmployeeException() {
		super();
	}
	public EmployeeException(String msg) {
		super(msg);
	}
}
