package com.cg.demoexception.ui;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class MyApplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
 		try {
			 new B().getAll(30000);
 		}catch(EmployeeException e) {		
			 System.out.println(e.getMessage());
 		}
	}
			  
		
		
		/*																				Example 1 of checked exception(File not fond)
		try {
			FileReader it = new FileReader("abc.txt");
			try {
				it.read();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	*/
/*																					Example 2 Class not found exception)
		try {				
			Class.forName("package com.cg.demoexception.ui.A");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		
		/*
		B temp = null;															(Unchecked)Exception in thread "main" java.lang.NullPointerException at com.cg.demoexception.ui.MyApplication.main(MyApplication.java:36)
		temp.a=10;
		*/
}


