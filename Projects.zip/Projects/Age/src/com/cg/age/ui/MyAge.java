package com.cg.age.ui;

import java.util.Scanner;

public class MyAge {

	public void Age() throws AgeException {
	Scanner scr = new Scanner(System.in);
	System.out.println("Enter your age: ");
	int age= scr.nextInt();
	if( age < 15) {
		 throw new AgeException("Invalid age");
	}
	else
	    System.out.println("Valid age");
}
}
