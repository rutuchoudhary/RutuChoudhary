package com.cg.age.ui;

public class Age {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		try {
			new MyAge().Age();
		} catch (AgeException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
	}

}
