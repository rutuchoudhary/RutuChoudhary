package com.cg.age.ui;

public class AgeException extends Exception{

	public AgeException() {
		super();
	}
	public AgeException(String msg) {
		super(msg);
	}
}
