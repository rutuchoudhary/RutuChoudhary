package com.cg.demotest.junit;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class DemoTest {
	
	Calculator cal;
	
	@BeforeEach
	public void doBeforeTest() {
		cal = new Calculator();
	
	}
	
	@Test
	public void doMyTestTwo() {
		assertEquals(12.0, cal.addNumber(10, 2));
		
	}
	
	@Test
	public void doMyTestOne() {
		assertEquals(8.0, cal.subNumber(10, 2));
		
	}
	
	@Test
	public void doMyTestThree() {
		assertEquals(20.0, cal.mulNumber(10, 2));
		
	}
	@Test
	public void doMyTestFour() {
		assertEquals(5.0, cal.divNumber(10, 2));
		
	}
	@AfterEach 
	public void doAfterTest() {
		cal = null;
		
	}
	
	
}
	
	
	
	
	
	
	
/*
	@BeforeAll
	public static void beforeAll() {
		System.out.println("Before All Started");
	}
	int a;
	@BeforeEach
	public void doBeforeTest() {
		a=10;
		System.out.println("Before the test");
		
	}
	
	@Test
	public void doMyTest() {
		System.out.println("In Test " );
	}
	
	@Test
	public void doMyTestTwo() {
		System.out.println("In Test2 " );
	}
	
	@AfterEach 
	public void doAfterTest() {
		System.out.println("After the test");
	}
	
//	@Test
//	public void doMyTestThree() {
//		System.out.println("In Test3 " );
//	}
	
	@AfterAll
	public static void afterAll() {
		System.out.println("After All Finished");
		
		*/
	

