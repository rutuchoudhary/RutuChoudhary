package com.cg.demotest.junit;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

public class DemoTestOne {

	int a;
	@Before
	public void doBeforeTest() {
		a=10;
		System.out.println("Before the test");
		
	}
	
	@Test
	public void doMyTest() {
		System.out.println("In Test ," +a);
		
	}
	
	@Test
	@Ignore
	public void doMyTestTwo() {
		System.out.println("In Test2 ," +a);
		
	}
	@After 
	public void doAfterTest() {
		System.out.println("After the test");
	}
}
