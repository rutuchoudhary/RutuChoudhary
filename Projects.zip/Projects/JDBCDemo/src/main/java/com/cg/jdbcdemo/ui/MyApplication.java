package com.cg.jdbcdemo.ui;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class MyApplication {

	public static void main(String[] args) {
		String driver,url,uname,upass;

		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn =DriverManager.getConnection("jdbc:mysql://localhost/test", "root", "Capgemini123");
			System.out.println("Connected");
			
			
/*//			PreparedStatement pstm = conn.prepareStatement("Insert into Employee value(?,?,?)");
			pstm.setInt(1,id);
			pstm.setString(2,name);
			pstm.setDouble(3, sal);
			pstm.executeUpdate();	*/
			
/*//			PreparedStatement pstm = conn.prepareStatement("Select empid,empname,empsalary from Employee");

	ResultSet result = pstm.executeQuery();					//to select the data
			
			while(result.next()) {
				int id=result.getInt("empid");
				String name = result.getString("empname");
				double salary = result.getDouble("empsalary");
				
				System.out.println(id+" "+name+" "+salary);
			}*/
			
			
			PreparedStatement pstm = conn.prepareStatement("Update Employee set id=? where name=?");
			
			pstm.setInt(1, 1002);
			pstm.setString(2, "Nikita");
			int count =pstm.executeUpdate();
			if(count ==1) {
				System.out.println("Updated");
			}
			
		/*	input from user
		  Scanner scr = new Scanner(System.in);
			System.out.println("Enter Emp Id");
			int id = scr.nextInt();
			System.out.println("Enter Emp Name");
			String name = scr.next();
			System.out.println("Enter Emp Salary");
			double sal = scr.nextDouble();
			
			*/
			/* static input
			 pstm.setInt(1,1001);
			pstm.setString(2,"Rutu");
			pstm.setDouble(3, 1082.2);
			pstm.executeUpdate();*/
			
											//to perform insert,update,delete operation
			
		} catch (ClassNotFoundException e) {
			System.out.println("Driver Not Loaded");
		} catch (SQLException e) {
			System.out.println("Connection Not Found");
			
		}
	}

}
