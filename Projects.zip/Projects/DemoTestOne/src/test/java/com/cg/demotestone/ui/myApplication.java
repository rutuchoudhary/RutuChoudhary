package com.cg.demotestone.ui;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.Reader;
import java.io.Writer;
import java.util.StringTokenizer;

public class myApplication {

	public static void main(String[] args) {
		
		Employee emp = new Employee(101,"Rutu",3000.0);
				
		
		try {
			OutputStream filewrite = new FileOutputStream("D:/myobject.txt");
			ObjectOutput objectWrite = new ObjectOutputStream(filewrite);
			objectWrite.writeObject(emp);
			objectWrite.flush();
			objectWrite.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Not Written");
		}
		
		InputStream fileRead;
		Employee empRead = null;
		try {
			 fileRead = new FileInputStream("D:/myobject.txt");
			ObjectInput objectread = new ObjectInputStream(fileRead);
			empRead = (Employee) objectread.readObject();
			objectread.close();
			System.out.println(empRead);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("Not able to read");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("Not Found");
		}
		
	}
}
		
	












































		
		/*
		// TODO Auto-generated method stub
//		InputStream fileread = null;
//		OutputStream filewrite = null;
		
		Reader fileread = null;
		Writer filewrite = null;
		BufferedReader bufreader = null;
		BufferedWriter bufwriter =null;
		try {
//			 fileread = new FileInputStream("D:/myread.txt");					//for reading
//			 filewrite = new FileOutputStream("D:/mywrite.txt");
//			fileread = new FileInputStream("MyRead.txt");						//to create file in eclipse
//			filewrite = new FileOutputStream("MyWrite.txt");
			fileread = new FileReader("MyRead.txt");
			bufreader = new BufferedReader(fileread);
			filewrite = new FileWriter("MyWrite.txt");
			bufwriter = new BufferedWriter(filewrite);
			
			int data=0;
//			System.out.println(data);														//(87 ASCII value of data)
			while((data=bufreader.readLine())!=null) {
//			while((data =fileread.read())>=0) {									//Reader loop
				filewrite.write(data);
//				System.out.println(data);
//				char c = (char)data;
//				System.out.println(c);
//				data++;																//no need of increment
			}
		} catch (FileNotFoundException e) {		
			// TODO Auto-generated catch block
			System.out.println("File Not Found");
		} catch (IOException e) {l
			// TODO Auto-generated catch block
			System.out.println("File can not read/open");
		} finally {
			try {
				fileread.close();
				filewrite.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				System.out.println("File not close");
			}
			
		}
		
		
		
		
//		StringBuffer st =new StringBuffer("Capgemini");
//		System.out.println(st.hashCode());
//		st.append("good");
	
//		StringTokenizer str =new StringTokenizer("Capgemini,is good company");
//		
//		System.out.println(str.nextToken());
//		System.out.println(str.nextToken(","));
//		
//		
	
		
		
		
		
//		String str = new String("Capgemini");
//		System.out.println(str.hashCode());
//		String str1 = "Igate";
//		System.out.println(str.hashCode());
//		
//		String str2="Capgemini";
//		System.out.println(str2.hashCode());
//		str2 ="Igate";
//		System.out.println(str2);
//		System.out.println(str2.hashCode());
//		System.out.println(str==str2);
//		System.out.println(str.equals(str2));
//		
//		
		
	}

}
*/