package com.cg.demoonespringcore.dto;

public class Item {
	private int id;
	private String nameOfShop;

	public Item() {
		System.out.println("In Item Constructor");
	}
	
	public void getData() {
		System.out.println("Item Data");
		
	}

	public Item(int id, String nameOfShop) {
		super();
		this.id = id;
		this.nameOfShop = nameOfShop;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNameOfShop() {
		return nameOfShop;
	}

	public void setNameOfShop(String nameOfShop) {
		this.nameOfShop = nameOfShop;
	}

	@Override
	public String toString() {
		return "Item [id=" + id + ", nameOfShop=" + nameOfShop + "]";
	}
	
}
