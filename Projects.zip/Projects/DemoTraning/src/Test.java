
import java.io.*; 

public class Test 
{ 
    public static void main(String args[]) 
       { 
          int i; 
            try 
              { 
                  Employee emp[]=new Employee[3]; 
                  System.out.println("Enter the Details of Employees"); 
                  for(i=0;i<=2;i++) 
                      { 
                          emp[i]=new Employee(); 
                          emp[i].SetData(); 
                      } 
                         System.out.println("The details of Employees are :"); 
                         for(i=0;i<=2;i++) 
                              { 
                                  emp[i].ShowDetail(); 
                               } 
              } 
                      catch(IOException e) 
                         { 
                          } 
       } 
}

class Employee 
  { 
      int Id,salary; 
      String Name; 
      void SetData() 
      throws IOException 
        { 
            BufferedReader bf=new BufferedReader(new InputStreamReader(System.in)); 
            String s; 
            System.out.println("Enter Employee Id :"); 
            s=bf.readLine(); 
            Id=Integer.parseInt(s); 
            System.out.println("Enter Name of Employee :"); 
            Name=bf.readLine(); 
            System.out.println("Enter Basic Salary "); 
            s=bf.readLine(); 
            salary=Integer.parseInt(s); 
        } 
           void ShowDetail() 
           { 
              System.out.println("Code :"+ Id); 
              System.out.println("Name : "+Name); 
              System.out.println("Salary :"+salary); 
           }
		public void GetData() {
			// TODO Auto-generated method stub
			
		} 
 } 
          
            
