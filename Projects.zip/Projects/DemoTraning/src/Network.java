

//abstract class A {
//	static {
//		System.out.println("In A");
//	}
//	static int x=50;
//}

////public class Main {
//	public class Main {
//	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub

//		System.out.println("In main");
////		new A();
////		A.x =55;
//		Class.forName("A");
//	}




//Student bob = new Student ();
//Student jian = new Student();
//bob.name = "Bob";
//bob.age = 19;
//jian = bob;
//jian.name = "Jian";
//System.out.println("Bob's Name: " + bob.name);
//}

	

	
	
//	class Rocket {
//private void blastOff() { System.out.print("bang "); }
//}
//public class Shuttle extends Rocket {
//public static void main(String[] args) {
//new Shuttle().go();
//}
//void go() {
//blastOff();
//// Rocket.blastOff(); // line A
//}
//private void blastOff() { System.out.print("sh-bang "); }
//}




//		static public void Main(String[] __A_V_) {
//			String $ = "";
//			for(int x=0; ++x < __A_V_.length; ) // for loop
//			$ += __A_V_[x];
//			System.out.println($);
//			}
//			}
public class Network {
Network(int x, Network n) {
id = x;
p = this;
if(n != null) p = n;
}
int id;
Network p;
public static void main(String[] args) {
Network n1 = new Network(1, null);
n1.go(n1);
}
void go(Network n1) {
Network n2 = new Network(1, n1);
Network n3 = new Network(1, n1);
System.out.println(n3.p.p.id);
System.out.println(n2.equals(n1));
System.out.println(n2==n1);
System.out.println(n2.hashCode()+" "+n1.hashCode());
}
}