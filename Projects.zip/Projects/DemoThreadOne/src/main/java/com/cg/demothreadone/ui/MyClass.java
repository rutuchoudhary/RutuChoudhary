package com.cg.demothreadone.ui;

import com.cg.demothreadone.dto.AccountDanger;

public class MyClass {

		public static void main (String [] args) {
			
			
			
			/*AccountDanger r = new AccountDanger();
			Thread one = new Thread(r);
			Thread two = new Thread(r);
			one.setName("Lucy");
			two.setName("Fred");
			one.start();
			two.start();*/
		}
}

		/*	public static void main(String[] args) {

		NameRunnable nr = new NameRunnable();
		Thread one = new Thread(nr);
		one.setName("Rutu");
		Thread two = new Thread(nr);
		two.setName("Nishu");
		Thread three = new Thread(nr);
		three.setName("Shirley");
		Thread four = new Thread(nr);
		four.setName("Kiara");
		
		one.start();
		Thread.currentThread().setPriority(Thread.MAX_PRIORITY);
//		one.setPriority(6);
//		one.yield();
		two.start();
//		two.setPriority(1);
		
		three.start();
		try {
			Thread.sleep(1000);
			} catch (InterruptedException e) { }
 
		four.start();
	
		
		
		//Worker w = new Worker(BankAccount);
		
	}

}*/