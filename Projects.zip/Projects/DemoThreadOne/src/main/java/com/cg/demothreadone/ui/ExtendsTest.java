package com.cg.demothreadone.ui;

public class ExtendsTest extends Thread{
	public static void main(String[] args) throws InterruptedException{
		String s1 = "geeksquiz";
        String s2 = "geeksquiz";
        System.out.println("s1 == s2 is:" + s1 == s2); 
		
		
	}
}




