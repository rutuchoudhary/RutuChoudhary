package com.cg.date.ui;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Formatter;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) throws ParseException {
		// TODO Auto-generated method stub

		Scanner scr= new Scanner(System.in);
		System.out.println("Enter date");
		String dt =scr.next();
//		Date date= null;
		SimpleDateFormat f =new SimpleDateFormat("yyyy/MM/dd");
//		int date =java.util.Calendar.getInstance().DATE;
//		System.out.println("dd");
//		Date date = Formatter.format();
//		date=scr
//		String d = f.format(dt);
//		String d = f.format(Date.parse(payback.creationDate.date));
		Date d = f.parse(dt);
		System.out.println(d.getDate());
		
//		System.out.println(java.util.Calendar.getInstance().DATE);
		
//		DateFormat fullMonthFormat = null;
//		Calendar cdr = fullMonthFormat.getCalendar();
//		System.out.println(cdr.DAY_OF_MONTH);
//		
	}

}

//
//System.out.println(date.getMonth());
//System.out.println(date.getDate());
//System.out.println(date.getDay());

