
package com.cg.playerselectionjpa.dao;                                       //import required packages
import java.sql.SQLException;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.NonUniqueResultException;
import javax.persistence.Query;

import com.cg.playerselectionjpa.dto.Game;
import com.cg.playerselectionjpa.dto.Player;
import com.cg.playerselectionjpa.exception.PlayerException;
import com.cg.playerselectionjpa.util.DBUtil;

public class PlayerDaoImpl implements PlayerDao{
	EntityManager em;
	public PlayerDaoImpl(){
		em=DBUtil.getConnection();                                         //open  the connection with database
	}
	public boolean save(Player p) throws SQLException ,PlayerException {
		
		Query query = em.createQuery( QueryInterface.querySelectGame);         //Execute the Query
query.setParameter(1,p.getSkill());
List result = query.getResultList();
if(result.size()==1) {
	try {
    em.persist(p);
   Query queryone= em.createQuery(QueryInterface.queryupdatePlayer);
   queryone.setParameter(1,query.getSingleResult());
  queryone.executeUpdate();
  em.getTransaction().commit();
}catch (Exception e) {
	throw new PlayerException("player id already exist please try with another Id");}}
else if(result.isEmpty()) {
	try {
	em.persist(p);
	em.getTransaction().commit();}catch (Exception e) {
		throw new PlayerException("player id already exist please try with another Id");}
}
		
		return true;
	}

	public List<Player> findbyskill(String skill) throws PlayerException {
		List<Player> playerList;
		
		Query query=em.createQuery(QueryInterface.querySelectSkill);
		query.setParameter(1,skill);
		try {
		playerList=query.getResultList();
		}
		catch (Exception e) {
			
			throw new PlayerException("player with this skill is not found");}
		
		if(playerList.isEmpty())
			throw new PlayerException("player with this skill is not found");	
		return playerList;
		}


	public Player findById(int playerId) throws PlayerException {
		Player p;
		
		Query query=em.createQuery(QueryInterface.querySelectId);
		query.setParameter(1,playerId);
		try {
		p=(Player) query.getSingleResult();
		}catch (NoResultException e) {
			
			throw new PlayerException("player with this id is not found");}
		return p;
	}

	public List<Player> findAll() {
		
		Query query=em.createQuery(QueryInterface.querySelectplayer);
		List<Player> playerList=query.getResultList();
		em.getTransaction().commit();
		return playerList;
	}

}
