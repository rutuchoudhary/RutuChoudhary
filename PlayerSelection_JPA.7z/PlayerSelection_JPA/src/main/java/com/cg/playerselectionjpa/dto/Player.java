package com.cg.playerselectionjpa.dto;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


@Entity
@Table(name="Player")
public class Player {
	@Column(name="playername")
	private String name;
	 @Id
     @Column(name="playerId")
	private int playerId;
	 @Column(name="playerskill")
    private String skill;
	
	
	


	


	public Player() {
		super();
	}
	
	
	

	public Player(String name, int playerId, String skill) {
		super();
		this.name = name;
		this.playerId = playerId;
		this.skill = skill;
		
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}


	@Override
	public String toString() {
		return "Player [name=" + name + ", playerId=" + playerId + ", skill=" + skill + "]";
	}




	
}

