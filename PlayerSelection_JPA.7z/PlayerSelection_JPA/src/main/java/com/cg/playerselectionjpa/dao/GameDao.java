package com.cg.playerselectionjpa.dao;
import java.util.List;

import com.cg.playerselectionjpa.dto.Game;
import com.cg.playerselectionjpa.exception.GameException;
public interface GameDao {
	public boolean save(Game game)  ;
	public List<Game> findByName(String name) throws GameException;
	public List<Game> findAll();
}
