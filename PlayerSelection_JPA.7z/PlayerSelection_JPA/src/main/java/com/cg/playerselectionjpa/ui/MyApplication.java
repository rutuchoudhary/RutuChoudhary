
 package com.cg.playerselectionjpa.ui;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;
import com.cg.playerselectionjpa.dto.Game;
import com.cg.playerselectionjpa.dto.Player;
import com.cg.playerselectionjpa.exception.GameException;
import com.cg.playerselectionjpa.exception.PlayerException;
import com.cg.playerselectionjpa.service.GameServiceImpl;
import com.cg.playerselectionjpa.service.PlayerServiceImpl;


public class MyApplication {
	static GameServiceImpl service;
	static PlayerServiceImpl serviceone;

	public MyApplication() {

	}
	public static void print() {
		System.out.println("1.Add Player");
		System.out.println("2.Add Game");
		System.out.println("3.Search player by Skill");
		System.out.println("4.Search player by id");
		System.out.println("5.Show All Player");
		System.out.println("6.Show All Game");
		System.out.println("7.Search game by game name");
	}

	public static void main(String[] args) {
		serviceone=new PlayerServiceImpl();
		service=new GameServiceImpl();
		Scanner in = new Scanner(System.in);
	int ch=0;
	     do {print();
		 System.out.println("Enter your choice");
			ch = in.nextInt();
	    	
	    	 switch(ch) {
	    	 case 1:
	    		 System.out.println("Enter player id");
	    		 int id = in.nextInt();
	    		 System.out.println("Enter player name");
	    		 String name = in.next();
	    		 System.out.println("Enter skill");
	    		  String skill = in.next();
	    		Player p=new Player();
	    		 p.setPlayerId(id);  
	 	         p.setName(name);  
	 	         p.setSkill(skill);
	 	         try {
					serviceone.addPlayer(p);
				} catch (PlayerException e) {
				
						System.out.println(e.getMessage());
					} catch (SQLException e) {

						System.out.println(e.getMessage());
					
				}
		       break;
		       
	    	 case 2:
	    		 System.out.println("Enter game id");
	    		 int idone = in.nextInt();
	    		 System.out.println("Enter game name");
	    		 String gamename = in.next();
	    		 
	    		Game g=new Game();
	    		g.setGameId(idone);
	    		g.setName(gamename);
	    		try {
	 	        service.addGame(g);
	    		}catch (PlayerException e) {
					
					System.out.println(e.getMessage());}
		       break;
		       
		       
	    	 case 3:
	    		 System.out.println("Enter any game name as skill");
	    		 String skillone=in.next();
	    		List<Player> mylist=null;
	    		try {
	    		 mylist=serviceone.searchBySkill(skillone);
	    		 for (Player playerData : mylist) {
						System.out.println("");
						System.out.println("Id is    " + playerData.getPlayerId());
						System.out.println("Name is  " + playerData.getName());
						System.out.println("Skill is  " + playerData.getSkill());
					}}catch (PlayerException e) {
						
						System.out.println(e.getMessage());}
		       break;
		       
		       
		       
	    	 case 4:
	    		 System.out.println("Enter Player Id to Search");
	    		 int idtwo=in.nextInt();
	    		 try {
	    		Player myplayer=serviceone.searchById(idtwo);
	    		System.out.println("");
				System.out.println("Id is    " + myplayer.getPlayerId());
				System.out.println("Name is  " + myplayer.getName());
				System.out.println("Skill is  " + myplayer.getSkill());}
	    		 catch (PlayerException e) {
						
						System.out.println(e.getMessage());}
		       break;
		       
		       
		       
	    	 case 5:
	    		List<Player> mylistone=null;
	    		 mylist=serviceone.showAll();
	    		 for (Player playerData : mylist) {
						System.out.println("");
						System.out.println("Id is    " + playerData.getPlayerId());
						System.out.println("Name is  " + playerData.getName());
						System.out.println("Skill is  " + playerData.getSkill());
					}
		       break;
		       
		       
	    	 case 6:
		    		List<Game> mygamelist=null;
		    		 mygamelist=service.showAll();
		    		 for (Game  gameData : mygamelist) {
							System.out.println("");
							System.out.println("Id is    " + gameData.getGameId());
							System.out.println("Name is  " + gameData.getName());
							System.out.println("The list of players ");
							try {
								List<Player> player = serviceone.searchBySkill(gameData.getName());
								System.out.println(player);}catch (PlayerException e) {
									
									System.out.println(e.getMessage());}
						}
			       break;
			       
			       
			       
	    	 case 7:
	    		 System.out.println("Enter game Name to search");
	    		 String gamenameone=in.next();
	    		List<Game> mylistgame=null;
	    		try {
	    		 mylistgame=service.searchByName(gamenameone);
	    		 for (Game gameData : mylistgame) {
	    			 System.out.println("");
						System.out.println("Id is    " + gameData.getGameId());
						System.out.println("Name is  " + gameData.getName());
						System.out.println("The list of players ");
						try {
						List<Player> player = serviceone.searchBySkill(gameData.getName());
						System.out.println(player);}catch (PlayerException e) {
							
							System.out.println(e.getMessage());}}
					} catch (GameException e) {
						
						System.out.println(e.getMessage());}
		       break;
	    		 
	    	 }
	    	 
	     }while(ch!=0);
	     
	
	
}}
	
