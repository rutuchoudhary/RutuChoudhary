package com.cg.playerselectionjpa.exception;

public class PlayerException extends RuntimeException{
	public PlayerException() {
		super();
	}
	public PlayerException(String msg) {
		super(msg);
	}
}
