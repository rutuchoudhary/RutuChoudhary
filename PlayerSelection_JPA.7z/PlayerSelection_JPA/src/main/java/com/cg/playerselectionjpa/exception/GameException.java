package com.cg.playerselectionjpa.exception;
public class GameException extends RuntimeException{
	public GameException() {
		super();
	}
	public GameException(String msg) {
		super(msg);
	}
}


