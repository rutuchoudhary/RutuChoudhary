package com.cg.playerselectionjpa.dto;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
@Entity
@Table(name="Game")
public class Game {
	@Id
     @Column(name="gameId")
	private int gameId;
	public int getGameId() {
		return gameId;
	}
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}
	@Column(name="gamename")
	private String name;
	@OneToMany(targetEntity=Player.class)
	@JoinColumn(name="gameId")
	private List<Player> myplayerlist=new ArrayList<Player>();
	@Override
	public String toString() {
		return "Game [gameId=" + gameId + ", name=" + name + ", myplayerlist=" + myplayerlist + "]";
	}
	public Game(int gameId, String name, List<Player> myplayerlist) {
		super();
		this.gameId = gameId;
		this.name = name;
		this.myplayerlist = myplayerlist;
	}
	public Game() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Player> getMyplayerlist() {
		return myplayerlist;
	}
	public void setMyplayerlist(List<Player> myplayerlist) {
		this.myplayerlist = myplayerlist;
	}
	
}