package com.cg.playerselectionjpa.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.cg.playerselectionjpa.util.DBUtil;
import com.cg.playerselectionjpa.dto.Game;
import com.cg.playerselectionjpa.exception.GameException;
import com.cg.playerselectionjpa.exception.PlayerException;

public class GameDaoImpl implements GameDao{
	EntityManager em;
	public GameDaoImpl(){
		
		em=DBUtil.getConnection();
	}
		public boolean save(Game game) {
			try {
			em.persist(game);
			
			Query queryone= em.createQuery(QueryInterface.queryupdate);
			   queryone.setParameter(1,game.getGameId());
			   queryone.setParameter(2,game.getName());
			  queryone.executeUpdate();
			em.getTransaction().commit();
		}catch (Exception e) {
			throw new GameException("Game id already exist please try with another Id");}
return true;}

	public List<Game> findByName(String name) throws GameException {
		List<Game> gameList;
		
		Query query=em.createQuery(QueryInterface.queryselect);
		query.setParameter(1,name);
		try {
		gameList=query.getResultList();}
		catch (Exception e) {
			throw new GameException("Game with this name is not found");}
		if(gameList.isEmpty())
			throw new GameException("Game with this name is not found");
		return gameList;
		
	}

	public List<Game> findAll() {
		
		Query query=em.createQuery(QueryInterface.querygame);
		List<Game> gameList=query.getResultList();
		return gameList;
	}
	

}
