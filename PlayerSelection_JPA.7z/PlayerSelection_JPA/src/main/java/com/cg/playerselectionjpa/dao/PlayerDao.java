package com.cg.playerselectionjpa.dao;
import com.cg.playerselectionjpa.dto.Player;
import java.sql.SQLException;
import java.util.List;
import com.cg.playerselectionjpa.exception.PlayerException;

public interface PlayerDao {
	
public boolean save(Player p) throws SQLException, PlayerException ;
	public List<Player> findbyskill(String skill) throws PlayerException;
	public Player findById(int playerId) throws PlayerException;
	public List<Player> findAll();
}
