package com.cg.playerselectionjpa.dao;

public interface QueryInterface {

	public static final String querySelectGame ="FROM Game gameId WHERE gamename =?";

	public static final String queryupdatePlayer ="update Player set gameId=?";

	public static final String querySelectSkill ="From Player Where playerskill=?";

	public static final String querySelectId ="From Player Where playerId=?";
	
	public static final String querySelectplayer ="From Player";
	
	public static final String queryupdate ="update Player set gameId=? where playerskill=?";
	
	public static final String queryselect ="From Game Where gamename=?";
	
	public static final String querygame ="From Game";
}
