package com.cg.playerselectionjpa.service;
import com.cg.playerselectionjpa.dto.Player;
import com.cg.playerselectionjpa.exception.PlayerException;

import java.sql.SQLException;
import java.util.List;

public interface PlayerService {
	
	public Player addPlayer(Player p) throws SQLException, PlayerException;
	public Player searchById(int playerId) throws PlayerException;
	public List<Player> searchBySkill(String skill) throws PlayerException;
   public List<Player> showAll();
}
