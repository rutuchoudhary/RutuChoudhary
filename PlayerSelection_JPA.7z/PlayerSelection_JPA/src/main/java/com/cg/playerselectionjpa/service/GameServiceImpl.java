package com.cg.playerselectionjpa.service;

import java.util.List;
import com.cg.playerselectionjpa.dao.GameDao;
import com.cg.playerselectionjpa.dao.GameDaoImpl;
import com.cg.playerselectionjpa.dto.Game;
import com.cg.playerselectionjpa.exception.GameException;

public class GameServiceImpl implements GameService{
	GameDaoImpl dao;
    public GameServiceImpl() {
    	dao=new GameDaoImpl();
    }
	public Game addGame(Game game) {
		// TODO Auto-generated method stub
		dao.save(game);
		return game;
	}


	public List<Game> searchByName(String name) throws GameException {
	return dao.findByName(name);
		
	}

	public List<Game> showAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
