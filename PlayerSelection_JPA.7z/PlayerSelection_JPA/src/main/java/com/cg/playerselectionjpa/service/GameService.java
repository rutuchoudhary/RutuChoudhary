package com.cg.playerselectionjpa.service;

import java.util.List;

import com.cg.playerselectionjpa.dto.Game;
import com.cg.playerselectionjpa.exception.GameException;

public interface GameService {
	public Game addGame(Game game) ;
	public List<Game> searchByName(String name) throws GameException;
	public List<Game>  showAll();}

