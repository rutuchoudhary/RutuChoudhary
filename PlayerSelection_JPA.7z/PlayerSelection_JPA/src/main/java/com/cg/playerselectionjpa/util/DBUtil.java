package com.cg.playerselectionjpa.util;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DBUtil {
	static EntityManager em=null;
	public static EntityManager getConnection() {
	EntityManagerFactory emf=Persistence.createEntityManagerFactory("playerprojectmanagement");  
	EntityManager em=emf.createEntityManager();  

	em.getTransaction().begin();  
	return em;
}
}