package com.cg.labassignmentspring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.labassignmentspring.dto.Trainee;

@Repository
public class TraineeDaoImpl implements TraineeDao {

	List<Trainee> myTraineeList = new ArrayList<>();

	@Override
	public Trainee saveTrainee(Trainee trainee) {
		myTraineeList.add(trainee);
		return null;
	}

	@Override
	public void removeTrainee(Trainee trainee) {
		myTraineeList.remove(trainee);
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		return null;
	}

	@Override
	public Trainee findTraineeById(Integer id) {
		for (Trainee t : myTraineeList) {
			if (t.getId() == id) {
				return t;
			}
		}

		return null;
	}

	@Override
	public List<Trainee> showAllTrainee() {
		return myTraineeList;
	}

}
