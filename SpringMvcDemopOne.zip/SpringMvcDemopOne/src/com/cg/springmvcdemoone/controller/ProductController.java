package com.cg.springmvcdemoone.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcdemoone.dto.Product;
import com.cg.springmvcdemoone.service.ProductService;

@Controller
public class ProductController {
	@Autowired
	ProductService productservice;

	// @RequestMapping(name="login",method=RequestMethod.GET)
	@GetMapping("login")
	public String loginPage() {
		return "mylogin";

	}

	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		System.out.println("Logged in");
		if (user.equals("admin") && pass.equals("1234")) {
			return "listpage";
		} else {
			return "error";

		}

	}

	@GetMapping("addpage")
	public ModelAndView getAddProduct(@ModelAttribute("prod") Product pro /* ,Map<String,Object> map */) { // either
																											// like this
		List<String> listOfcategory = new ArrayList<>();
		listOfcategory.add("Electronics");
		listOfcategory.add("FastFood");
		listOfcategory.add("Vegetables");
		listOfcategory.add("Stationary");
		listOfcategory.add("cloths");
		// map.put("cato",listOfcategory);
		return new ModelAndView("addproduct", "cato", listOfcategory); // or this

	}

	@GetMapping("showpage")
	public ModelAndView showProduct() {
		List<Product> myAllProduct = productservice.showAllProduct();
		return new ModelAndView("showall", "showproduct", myAllProduct);
	}

	@PostMapping("addproduct")
	public ModelAndView addProduct(@ModelAttribute("prod") Product pro) {
		System.out.println(pro);
		Product product = productservice.addProduct(pro);
		return new ModelAndView("success","info",product);

	}

}
