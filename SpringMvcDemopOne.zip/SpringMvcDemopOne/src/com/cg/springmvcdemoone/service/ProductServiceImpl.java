package com.cg.springmvcdemoone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcdemoone.dao.ProductDao;
import com.cg.springmvcdemoone.dto.Product;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Autowired
	ProductDao productdao;

	@Override
	public Product addProduct(Product pro) {
		return productdao.saveProduct(pro);
	}

	@Override
	public List<Product> showAllProduct() {
		return productdao.showAllProduct();
	}

}
