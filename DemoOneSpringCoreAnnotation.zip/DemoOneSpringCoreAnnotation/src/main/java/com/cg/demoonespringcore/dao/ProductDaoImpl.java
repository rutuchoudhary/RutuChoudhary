package com.cg.demoonespringcore.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.demoonespringcore.dto.Product;

@Repository("productdao")
public class ProductDaoImpl implements ProductDao {
	List<Product> productList = new ArrayList<Product>();

	public ProductDaoImpl() {
		System.out.println("In dao");
	}
	public void saveProduct(Product pro) {
		productList.add(pro);
	}

	public List<Product> showAllProduct() {
		return productList;
	}

}
