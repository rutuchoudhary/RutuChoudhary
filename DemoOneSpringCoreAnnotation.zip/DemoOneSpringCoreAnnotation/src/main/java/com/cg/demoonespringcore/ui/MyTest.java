package com.cg.demoonespringcore.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.demoonespringcore.config.JavaConfig;
import com.cg.demoonespringcore.dao.ProductDaoImpl;
import com.cg.demoonespringcore.dto.Product;
import com.cg.demoonespringcore.dto.Tranaction;
import com.cg.demoonespringcore.service.ProductService;

public class MyTest {
	@Autowired
	static ProductService productService;
	public static void main(String[] args) {
		AnnotationConfigApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);

		
		Product myProduct = (Product) app.getBean("prod");
		Tranaction myTransaction = (Tranaction) app.getBean("tran");
		
		ProductDaoImpl impl = (ProductDaoImpl) app.getBean("productdao");

		myProduct.setId(101);
		myProduct.setName("Product");
		myProduct.setPrice(1234.5);
		myProduct.setDescription("Random Product");

		myTransaction.setId(1);
		myTransaction.setAmount(2345);
		myTransaction.setDescription("For Listed Product");
		
		System.out.println(myProduct);
		productService.addProduct(myProduct);
		
		
		productService.showAllProduct();
	}

}
