package com.cg.SparkMessagingApplicationSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.SparkMessagingApplicationSpringBoot")
public class SparkMessagingApplicationSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SparkMessagingApplicationSpringBootApplication.class, args);
		System.out.println("In Project");
	}

}
