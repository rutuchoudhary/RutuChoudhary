package com.cg.SparkMessagingApplicationSpringBoot.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SparkMessagingApplicationSpringBoot.dao.ChatHistoryDao;
import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;

@Service
public class ChatHistoryServiceImpl implements ChatHistoryService {

	@Autowired
	ChatHistoryDao dao;

	@Override
	public Message addMessage(Message message) {
		return dao.save(message);
	}

	@Override
	public List<Message> searchBySenderOrReceiverId(int id) {
		return null;
	}

	@Override
	public List<ChatHistory> showAllChatHistory() {
		return null;
	}

}
