package com.cg.SparkMessagingApplicationSpringBoot.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SparkMessagingApplicationSpringBoot.dao.ChatHistoryDao;
import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;
import com.cg.SparkMessagingApplicationSpringBoot.exception.UserException;

@Service
@Transactional
public class ChatHistoryServiceImpl implements ChatHistoryService {

	@Autowired
	ChatHistoryDao dao;
	static final Logger logger = Logger.getLogger(ChatHistoryServiceImpl.class);

	@Override
	public Message addMessage(Message message) {
		PropertyConfigurator.configure("D:\\JavaDemoRC\\SparkMessagingApplicationSpringBoot\\src\\main\\java\\resources\\log4j.properties");
		logger.info("Message added successfully");
		return dao.save(message);
	}

	@Override
	public List<Message> searchBySenderOrReceiverId(Integer id) {
		List<Message> msgList = dao.findBySenderOrReceiverId(id);
		if (msgList.isEmpty()) {
			throw new UserException("There are no messages against entered id because no user with this id");
		}
		return msgList;
	}

	@Override
	public List<ChatHistory> showAllChatHistory() {
		List<ChatHistory> chathisList = dao.findAllChatHistory();
		if (chathisList.isEmpty()) {
			throw new UserException("No Conversation happened yet");
		}
		return chathisList;
	}

}
