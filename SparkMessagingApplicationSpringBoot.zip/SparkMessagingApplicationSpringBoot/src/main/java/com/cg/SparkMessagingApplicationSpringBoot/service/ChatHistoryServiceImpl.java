package com.cg.SparkMessagingApplicationSpringBoot.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.SparkMessagingApplicationSpringBoot.dao.ChatHistoryDao;
import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;

@Service
public class ChatHistoryServiceImpl implements ChatHistoryService {

	@Autowired
	ChatHistoryDao dao;

	@Override
	public Message addMessage(Message message) {
		return dao.save(message);
	}

	@Override
	public List<Message> searchBySenderOrReceiverId(int id) {
		return dao.findBySenderOrReceiverId(id);
	}

	@Override
	public ChatHistory showAllChatHistory() {
		ChatHistory chatHistory = new ChatHistory();
		List<ChatHistory> chathis = new ArrayList<>();
		/*chathis.setMessage(dao.findAll());
		return dao.findAllChatHistory();*/
		
		List<Message> msgList = dao.findAll();
		chatHistory.setMessage(msgList);
		
		return chatHistory;
	}

}
