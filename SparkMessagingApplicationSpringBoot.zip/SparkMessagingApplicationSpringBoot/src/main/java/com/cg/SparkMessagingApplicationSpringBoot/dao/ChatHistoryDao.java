package com.cg.SparkMessagingApplicationSpringBoot.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;

public interface ChatHistoryDao extends JpaRepository<Message, Integer>{
	

}
