package com.cg.SparkMessagingApplicationSpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;

public interface ChatHistoryDao extends JpaRepository<Message, Integer> {

	@Query(nativeQuery = true, value = "select * from Message m where m.sender_id=:userid or m.receiver_id=:userid")
	public List<Message> findBySenderOrReceiverId(@Param("userid") Integer id);

/*	@Query(nativeQuery=true, value="select new com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory(c.chat_history_id,m.text, m.date, m.sender_id, m.receiver_id, m.chat_histoy_id_fk) from ChatHistory c "
			+ ",Message m ")
*/
	//	@Query("select DISTINCT m from Message m left join fetch m.ChatHistory")
//	@Query(nativeQuery=true, value="select m from Message, IN(m.chathistory) c")
//	@Query(nativeQuery=true,value="select m.* from chat_history c inner join Message m on c.chat_history_id = m.chat_histoy_id_fk")
	@Query(nativeQuery=true,value="select * from Message m inner join m.chat_history)")
	public List<ChatHistory> findAllChatHistory();

}

