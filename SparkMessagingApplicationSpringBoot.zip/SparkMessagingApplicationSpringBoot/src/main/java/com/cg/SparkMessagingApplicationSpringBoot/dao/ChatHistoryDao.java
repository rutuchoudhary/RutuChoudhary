package com.cg.SparkMessagingApplicationSpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;

public interface ChatHistoryDao extends JpaRepository<Message, Integer>{

	@Query("from Message where sender_id=?1")
	public List<Message> findBySenderOrReceiverId(int id);
	
	
	/*@Query("select new package.ChatHistory(m.text, m.date, m.sender, m.receiver) from Message m")
	public List<ChatHistory> findAllChatHistory();*/

}
