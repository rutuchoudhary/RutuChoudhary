package com.cg.SparkMessagingApplicationSpringBoot.controller;

import static org.mockito.Mockito.never;

import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.SparkMessagingApplicationSpringBoot.dto.ChatHistory;
import com.cg.SparkMessagingApplicationSpringBoot.dto.Message;
import com.cg.SparkMessagingApplicationSpringBoot.dto.User;
import com.cg.SparkMessagingApplicationSpringBoot.exception.UserException;
import com.cg.SparkMessagingApplicationSpringBoot.service.ChatHistoryService;

@RestController
@RequestMapping("/chathistory")
public class Controller {

	@Autowired
	ChatHistoryService service;

	@RequestMapping(value = "/add", method = RequestMethod.POST)
	public ResponseEntity<Message> addMessage(@RequestParam("text") String text, @RequestParam("date") Timestamp date,
			@RequestParam("sender_id") int senderid, @RequestParam("sender_name") String sendername,
			@RequestParam("receiver_id") int receiverid, @RequestParam("receiver_name") String receivername,
			@RequestParam("chat_histoy_id_fk") int chathistoryid) {

		User user = new User();
		user.setId(senderid);
		user.setName(sendername);

		User userone = new User();
		userone.setId(receiverid);
		userone.setName(receivername);

		ChatHistory chatHistory = new ChatHistory();
		chatHistory.setUser(user);

		Message message = new Message();
		message.setText(text);
		message.setDate(new Timestamp(System.currentTimeMillis()));
		message.setSender(user);
		message.setReceiver(userone);
		message.setChathistory(chatHistory);

		Message mess = service.addMessage(message);
		return new ResponseEntity<Message>(mess, HttpStatus.OK);
	}

	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public ResponseEntity<List<ChatHistory>> getAllChathistory() {
		List<ChatHistory> ch = service.showAllChatHistory();
		return new ResponseEntity(ch, HttpStatus.OK);
	}

	@RequestMapping(value = "/search", method = RequestMethod.POST)
	public ResponseEntity<List<Message>> searchMessage(@RequestParam("uid") Integer id) {
		List<Message> msgList = service.searchBySenderOrReceiverId(id);
		return new ResponseEntity(msgList, HttpStatus.OK);
	}

	@ExceptionHandler({ UserException.class })
	public ResponseEntity handleTestException(UserException u) {
		return new ResponseEntity(u.getMessage(), HttpStatus.NOT_FOUND);

	}
}
