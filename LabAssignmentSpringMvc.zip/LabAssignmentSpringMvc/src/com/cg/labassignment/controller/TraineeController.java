package com.cg.labassignment.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class TraineeController {
//	@RequestMapping(name="login", method=RequestMethod.GET)
	@GetMapping("login")
	public String loginPage() {
		return "mylogin";

	}

	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		System.out.println("Logged in");
		if (user.equals("admin") && pass.equals("1234")) {
			return "new";
		} else {
			return "error";

		}
	}

}
