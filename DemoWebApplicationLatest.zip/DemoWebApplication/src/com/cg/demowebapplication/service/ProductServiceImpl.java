package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dao.ProductDaoImpl;
import com.cg.demowebapplication.dto.Product;

public class ProductServiceImpl implements ProductService {
	ProductDaoImpl dao; 

	public ProductServiceImpl() {
		dao = new ProductDaoImpl();
	}

	@Override
	public void addproduct(Product prod) {
		dao.saveproduct(prod);
	}

	@Override
	public List<Product> showProduct() {
		return dao.showAll();
	}

}
