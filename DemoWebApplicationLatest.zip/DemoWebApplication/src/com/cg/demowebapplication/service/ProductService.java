package com.cg.demowebapplication.service;

import java.util.List;

import com.cg.demowebapplication.dto.Product;

public interface ProductService {
	public void addproduct(Product prod);

	public List<Product> showProduct();

}
