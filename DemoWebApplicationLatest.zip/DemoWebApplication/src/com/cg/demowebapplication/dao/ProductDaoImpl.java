package com.cg.demowebapplication.dao;

import java.util.LinkedList;
import java.util.List;

import com.cg.demowebapplication.dto.Product;

public class ProductDaoImpl implements ProductDao {

	List<Product> mylist = new LinkedList<>();

	@Override
	public void saveproduct(Product prod) {
		mylist.add(prod);
	}

	@Override
	public List<Product> showAll() {
		return mylist;
	}

}
