package com.cg.demowebapplication.dao;

import java.util.List;

import com.cg.demowebapplication.dto.Product;

public interface ProductDao {
	public void saveproduct(Product prod);

	public List<Product> showAll();
}
