package com.cg.demowebapplication.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.demowebapplication.dto.Product;
import com.cg.demowebapplication.service.ProductServiceImpl;

/**
 * Servlet implementation class ProductController
 */
@WebServlet(urlPatterns= {"/add","/show","/addproduct"})
public class ProductController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	ProductServiceImpl service;
    public ProductController() {
        super();
         service = new ProductServiceImpl();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		response.getWriter().append("Served at: ").append(request.getContextPath());
		
		doPost(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
//		doGet(request, response);
		String  url=request.getServletPath();

		if(url.equals("/add")) {
			//AddProduct.jsp
			RequestDispatcher req =request.getRequestDispatcher("AddProduct.jsp");
			req.forward(request, response);						//sending request and response object to addproduct.jsp
			
		}
		if(url.equals("/show")) {
			//ShowProduct.jsp
			List<Product> myList = service.showProduct();
			request.setAttribute("myprod", myList);
			
			RequestDispatcher req =request.getRequestDispatcher("ShowProduct.jsp");
			req.forward(request, response);	
		}
		if(url.equals("/addproduct")) {
			//fetch the data from AddProduct.jsp
		
		String productId=request.getParameter("prodid");
		String productName=request.getParameter("prodname");
		String productPrice=request.getParameter("prodprice");
		String productOnline=request.getParameter("prodonline");
		String productCategory=request.getParameter("cato");
		
		Product prod =new Product();
		prod.setId(Integer.parseInt(productId));
		prod.setName(productName);
		prod.setPrice(Double.parseDouble(productPrice));
		prod.setOnline(productOnline);
		prod.setCategory(productCategory);
		
		service.addproduct(prod);
		//request.setAttribute("myprod", prod); 			//key and value
		RequestDispatcher res = request.getRequestDispatcher("product.jsp");
		
		res.forward(request, response);
		
		/*
		PrintWriter out = response.getWriter();
		
		out.println("Product Id is "+productId);
		out.println("Product Name is "+productName);
		out.println("Product Price is "+productPrice);
		out.println("Product is Online?  "+productOnline);
		out.println("Product Category is "+productCategory);*/
		}
	}

}
