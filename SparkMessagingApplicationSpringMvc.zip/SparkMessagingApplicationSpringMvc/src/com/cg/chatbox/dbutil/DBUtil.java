package com.cg.chatbox.dbutil;

import java.util.ArrayList;
import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;

public class DBUtil {
	public static List<Message> messages = new ArrayList<>();
	public static List<ChatHistory> chathistory = new ArrayList<>();

}
