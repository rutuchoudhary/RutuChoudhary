package com.cg.chatbox.dao;

import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

public class ChatHistoryDaoImpl implements ChatHistoryDao{

	@Override
	public Message saveMessage(Message message) {
		return null;
	}

	@Override
	public List<Message> findBySenderOrReceiver(User user) {
		return null;
	}

	@Override
	public List<ChatHistory> getAllChatHistory() {
		return null;
	}

}
