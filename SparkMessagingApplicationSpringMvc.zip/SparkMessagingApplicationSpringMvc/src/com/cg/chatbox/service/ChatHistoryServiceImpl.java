package com.cg.chatbox.service;

import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

public class ChatHistoryServiceImpl implements ChatHistoryService{

	@Override
	public Message addMessage(Message message) {
		return null;
	}

	@Override
	public List<Message> searchBySenderOrReceiver(User user) {
		return null;
	}

	@Override
	public List<ChatHistory> getAllChatHistory() {
		return null;
	}

}
