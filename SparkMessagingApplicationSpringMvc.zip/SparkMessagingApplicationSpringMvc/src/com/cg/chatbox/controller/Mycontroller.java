package com.cg.chatbox.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class Mycontroller {

	@RequestMapping(name="login", method=RequestMethod.GET)
//	@GetMapping(value = "login")
	public String loginPage() {
		return "mylogin";
	}

	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		System.out.println("Logged In");
		if (user.equals("admin") && pass.equals("1234")) {
			return "option";
		} else {
			return "error";
		}
	}
}
