package com.cg.chatbox.service;

import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

public interface ChatHistoryService {
	public Message addMessage(Message message) ;

	public List<Message> searchBySenderOrReceiver(User user) ;

	public List<ChatHistory> getAllChatHistory();

}
