package com.cg.chatbox.dto;

import java.sql.Timestamp;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name="Message")
public class Message {
	@Id
	@Column(name="message_id")
	private int id;
	@Column(name="text")
	private String text;
	@Column(name="date")
	private Timestamp date;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="sender_id")
	private User sender;
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="receiver_id")
	private User receiver;

	public Message() {
	}

	public Message(int id, String text, Timestamp date, User sender, User receiver) {
		super();
		this.id = id;
		this.text = text;
		this.date = date;
		this.sender = sender;
		this.receiver = receiver;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public Timestamp getDate() {
		return date;
	}

	public void setDate(Timestamp date) {
		this.date = date;
	}

	public User getSender() {
		return sender;
	}

	public void setSender(User sender) {
		this.sender = sender;
	}

	public User getReceiver() {
		return receiver;
	}

	public void setReceiver(User receiver) {
		this.receiver = receiver;
	}

	@Override
	public String toString() {
		return "Message [id=" + id + ", text=" + text + ", date=" + date + ", sender=" + sender + ", receiver="
				+ receiver + "]";
	}
}
	
