package com.cg.chatbox.dao;

import java.awt.Window.Type;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.util.DBUtil;

public class ChatHistoryDaoImpl implements ChatHistoryDao {
	EntityManager em;
	public ChatHistoryDaoImpl() {
		em =DBUtil.em;
	}
	
	public Message saveMessage(Message message) {
		em.getTransaction().begin();
		Query user_exist = em.createQuery("select user from User user where user_id in(?,?)");
		user_exist.setParameter(1,message.getSender().getId());
		user_exist.setParameter(2,message.getReceiver().getId());
		
		List result = user_exist.getResultList();
		if(result.isEmpty()) {
		em.persist(message);
		em.getTransaction().commit();
		}
		else if(result.size()==1) {
			em.merge(message);
			em.getTransaction().commit();
		}
		else {
			em.flush();
			em.clear();
			em.merge(message);
			em.getTransaction().commit();
		}
		TypedQuery<ChatHistory> chathistory = em.createQuery("select c from ChatHistory c, in (c.user) u where u.id=?",ChatHistory.class);
		chathistory.setParameter(1,message.getSender().getId());
		ChatHistory c = chathistory.getSingleResult();
		List<Message> msgs = c.getMessage();
		msgs.add(message);
		c.setMessage(msgs);
		em.persist(chathistory);
		/*ChatHistory chathis = new ChatHistory();
//		chathis.setId(message.getSender().getId());
//		System.out.println(chathis);
		List<Message> msg = new ArrayList<Message>();
//		if(!chathis.getMessage().isEmpty())
//		msg = chathis.getMessage();
		msg.add(message);
		chathis.setMessage(msg);
		chathis.setUser(message.getSender());
		em.persist(chathis);*/
		em.getTransaction().commit();
		return null;
	}

	public List<Message> findBySenderOrReceiver(User user) {
		Query search = em.createQuery("from Message where sender_id=? or receiver_id=?");
		search.setParameter(1,user.getId());
		search.setParameter(2,user.getId());
		
		@SuppressWarnings("unchecked")
		List<Message> messageList = search.getResultList();
		return messageList;
	}

	public List<ChatHistory> getAllChatHistory() {
		return null;
	}

}