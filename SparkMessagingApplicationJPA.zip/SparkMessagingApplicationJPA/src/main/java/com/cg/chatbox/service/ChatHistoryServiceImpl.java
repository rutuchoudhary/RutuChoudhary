package com.cg.chatbox.service;

import java.util.List;

import com.cg.chatbox.dao.ChatHistoryDaoImpl;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

public class ChatHistoryServiceImpl implements ChatHistoryService {
	ChatHistoryDaoImpl dao = new ChatHistoryDaoImpl();

	public Message addMessage(Message message) {

		return dao.saveMessage(message);
	}

	public List<Message> searchBySenderOrReceiver(User user) {
		return dao.findBySenderOrReceiver(user);
	}

	public List<ChatHistory> getAllChatHistory() {
		return dao.getAllChatHistory();
	}

}
