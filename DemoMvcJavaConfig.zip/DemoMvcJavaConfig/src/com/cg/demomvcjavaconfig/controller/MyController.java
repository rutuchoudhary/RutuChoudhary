package com.cg.demomvcjavaconfig.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.demomvcjavaconfig.dto.Product;
import com.cg.demomvcjavaconfig.service.ProductService;

@Controller
public class MyController {

	@Autowired
	ProductService service;

	@GetMapping(value = "login")
	public String loginPage() {
		return "mylogin";
	}

	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		if (user.equals("admin") && pass.equals("1234")) {
			return "listproduct";
		} else {
			return "error";
		}
	}

	@GetMapping("add")
	public ModelAndView getAddproduct(@ModelAttribute("prod") Product pro) {
		List<String> listOfCategory = new ArrayList<>();
		listOfCategory.add("Electronics");
		listOfCategory.add("Book");
		listOfCategory.add("Cosmetics");
		return new ModelAndView("addproduct", "cato", listOfCategory);
	}

	@GetMapping("show")
	public ModelAndView showProduct() {
		List<Product> myProducts = service.showAllProduct();
		return new ModelAndView("showAll", "showproduct", myProducts);
	}

	@PostMapping("addproduct")
	public ModelAndView addproduct(@ModelAttribute("prod") Product pro) {
		Product product = service.addProduct(pro);
		return new ModelAndView("listproduct", "key", product);
	}

}
