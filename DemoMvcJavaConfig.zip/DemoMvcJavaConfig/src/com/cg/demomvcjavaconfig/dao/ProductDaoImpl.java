package com.cg.demomvcjavaconfig.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.demomvcjavaconfig.dto.Product;

@Repository
public class ProductDaoImpl implements ProductDao {

	@PersistenceContext
	EntityManager entitymanager;

	@Override
	public Product saveProduct(Product pro) {
		entitymanager.persist(pro);
		entitymanager.flush();
		return pro;
	}

	@Override
	public List<Product> showAllProduct() {
		Query query=entitymanager.createQuery("from product");
		List<Product> myList = query.getResultList();
		return myList;
	}

}
