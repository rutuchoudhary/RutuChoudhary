package com.cg.demomvcjavaconfig.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="prdoct_mvc")
public class Product {
	@Id
	@Column(name="prod_id")
	private Integer id;
	@Column(name="prod_name")
	private String name;
	@Column(name="prod_description")
	private String description;
	@Column(name="prod_cato")
	private String categoery;
	@Column(name="price")
	private Double price;
	
	public Product() {
	}

	public Product(Integer id, String name, String description, String categoery, Double price) {
		super();
		this.id = id;
		this.name = name;
		this.description = description;
		this.categoery = categoery;
		this.price = price;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCategoery() {
		return categoery;
	}

	public void setCategoery(String categoery) {
		this.categoery = categoery;
	}

	public Double getPrice() {
		return price;
	}

	public void setPrice(Double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", description=" + description + ", categoery=" + categoery
				+ ", price=" + price + "]";
	}
	
	
}
