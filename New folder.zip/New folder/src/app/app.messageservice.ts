import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';

@Injectable({
    providedIn:'root'
})

export class MessageService{

     constructor(private http:HttpClient) {}

     addMessage(msg:any){
         let input = new FormData();
/**key is the attribute from particular class also defined in postman */
input.append("text",msg.text);
input.append("date",msg.date);
input.append("sender.id",msg.senderid);
input.append("sender.name",msg.sendername);
input.append("receiver.id",msg.receiverid);
input.append("receiver.name",msg.receivername);

return this.http.post("http://localhost:9093/chathistory/add",input);
     }

}