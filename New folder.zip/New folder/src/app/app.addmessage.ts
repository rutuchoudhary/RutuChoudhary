import {Component} from '@angular/core';
import {MessageService} from './app.messageservice';
import {Message} from './app.message';
import {User} from './app.user';


@Component({
    selector:'msg-app',
    templateUrl:'app.addmessage.html'
})



export class MessageComponent{
    messages:Message[];
    model:any={};
    constructor(private msgservice:MessageService) {
        console.log("In Constructor");
    }

addMessage() {
    this.msgservice.addMessage(this.model).subscribe((data:any)=>console.log(data));

    }
}