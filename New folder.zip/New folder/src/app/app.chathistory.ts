import {Message} from './app.message';
import {User} from './app.user';

class ChatHistory{
    user:User;
    // message:List<Message>;
}

