package com.cg.labassignmentspring.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.labassignmentspring.dto.Trainee;
import com.cg.labassignmentspring.service.TraineeService;

@Controller
public class TraineeController {

	@Autowired
	TraineeService traineeservice;

	// @RequestMapping(name="login",method=RequestMethod.GET)
	@GetMapping("login")
	public String loginPage() {
		return "mylogin";

	}

	@PostMapping("checklogin")
	public String doLogin(@RequestParam("uname") String user, @RequestParam("upass") String pass) {
		System.out.println("Logged in");
		if (user.equals("admin") && pass.equals("1234")) {
			return "listpage";
		} else {
			return "error";

		}

	}

	@GetMapping("add")
	public ModelAndView getAddTrainee(@ModelAttribute("trainee") Trainee train) {
		List<String> domainList = new ArrayList<>();
		domainList.add("Java");
		domainList.add("Oracle");
		domainList.add("Mainframe");
		domainList.add(".Net");
		return new ModelAndView("addtrainee", "dom", domainList);
	}

	@GetMapping("showall")
	public ModelAndView showTrainee() {
		List<Trainee> mylist = traineeservice.showAllTrainee();
		return new ModelAndView("show", "showtrainee", mylist);
	}

	@PostMapping("addtrainee")
	public ModelAndView addTrainee(@ModelAttribute("trainee") Trainee train) {
		Trainee trainee = traineeservice.addTrainee(train);
		return new ModelAndView("success", "info", trainee);
	}
	
	@GetMapping("search")
	public ModelAndView search() {
		return new ModelAndView("searchtrainee");
	}

	
	@PostMapping("searchtrainee")
	public ModelAndView getSearchTrainee(@RequestParam("traineeid") int id,Model m) {
		Trainee trainee =traineeservice.searchTraineeById(id);
		m.addAttribute("inf",trainee);
		return new ModelAndView("searchtrainee");
		
	}
	
	@GetMapping("delete")
	public ModelAndView delete() {
	return new ModelAndView("delete");
	}
	
	@PostMapping("delete")
	public ModelAndView deleteTrainee(@RequestParam("tid") int tid, Model m) {
		Trainee trainee = traineeservice.searchTraineeById(tid);
		m.addAttribute("key", trainee);
		traineeservice.removeTrainee(trainee);
		return new ModelAndView("delete");
	}
	
	@GetMapping("update")
	public ModelAndView update() {
	return new ModelAndView("update");
	}
	
	@PostMapping("update")
	public ModelAndView updateProduct(@RequestParam("traineeid") int id,Model m)
	{  
		Trainee trainee= traineeservice.searchTraineeById(id);
		m.addAttribute("up", trainee);
		
		return new ModelAndView("update");
		
	}
	
}
