package com.cg.chatbox.dao;

import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;

public interface ChatHistoryDao {

	public Message saveMessage(Message message);

	public List<Message> findBySenderOrReceiver(Integer id);

	public List<ChatHistory> getAllChatHistory();
}
