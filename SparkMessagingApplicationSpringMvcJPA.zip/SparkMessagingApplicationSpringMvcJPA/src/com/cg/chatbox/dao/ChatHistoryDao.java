package com.cg.chatbox.dao;

import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

public interface ChatHistoryDao {

	public User searchUser(int id);

	public Message saveMessage(Message message);

	public List<Message> findBySenderOrReceiver(User user);
	
	public ChatHistory saveChatHistory(ChatHistory chathistory);

	public List<ChatHistory> getAllChatHistory();
}
