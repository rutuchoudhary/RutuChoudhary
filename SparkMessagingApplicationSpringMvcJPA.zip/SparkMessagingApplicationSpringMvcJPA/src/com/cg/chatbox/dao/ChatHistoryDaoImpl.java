package com.cg.chatbox.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;

@Repository
public class ChatHistoryDaoImpl implements ChatHistoryDao {

	@PersistenceContext
	EntityManager entitymanager;

	List<Message> myMessages = new ArrayList<>();
	List<ChatHistory> allChatHistory = new ArrayList<>();

	@Override
	public Message saveMessage(Message message) {

		ChatHistory chathistory = new ChatHistory();
		chathistory.setUser(message.getSender());
		entitymanager.persist(chathistory);
		message.setChathistory(chathistory);

		Message msg = getMessageById(message.getSender().getId()) ;
		if( msg==null)  {
		entitymanager.persist(message);
		entitymanager.flush();
		} else {
			Message ms = new Message();
			ms.setText(message.getText());
			ms.setDate(message.getDate());
			entitymanager.persist(ms);
			entitymanager.flush();
		}

		return message;
	}
	public Message getMessageById(Integer id) {
		Message m=null;
		try {
		Query find = entitymanager.createQuery("from Message where sender_id=?1");
		find.setParameter(1,id);
		 m =(Message) find.getSingleResult();
	}catch (NoResultException e) {
		System.out.println("No ID Found");
	}
		return m;
	}

	@Override
	public List<Message> findBySenderOrReceiver(Integer id) {
		Query search = entitymanager.createQuery("from Message where sender_id=?1 or receiver_id=?1");
		search.setParameter(1, id);
		@SuppressWarnings("unchecked")
		List<Message> messageList = search.getResultList();
		return messageList;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<ChatHistory> getAllChatHistory() {
		Query all = entitymanager.createQuery("from Message");
		allChatHistory = all.getResultList();
		return allChatHistory;
	}

}
