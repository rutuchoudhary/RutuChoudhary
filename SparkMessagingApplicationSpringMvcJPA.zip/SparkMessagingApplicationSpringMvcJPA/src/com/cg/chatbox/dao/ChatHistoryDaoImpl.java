package com.cg.chatbox.dao;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;

import com.cg.chatbox.dbutil.DBUtil;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

@Repository
public class ChatHistoryDaoImpl implements ChatHistoryDao {

	@PersistenceContext
	EntityManager entitymanager;
	
	
	List<User> userList = new ArrayList<>();
	List<Message> myMessages = new ArrayList<>();
	List<ChatHistory> allChatHistory = new ArrayList<>();

	@Override
	public User searchUser(int id) {
		for(User u: userList) {
			if(u.getId()==id)
				return u;
		}
		return null;
	}

	@Override
	public Message saveMessage(Message message) {
		entitymanager.persist(message);
		entitymanager.flush();
		return message;
	}

	@Override
	public List<Message> findBySenderOrReceiver(User user) {
		for (Message m : DBUtil.messages)
			if (m.getSender().getId() == user.getId() || m.getReceiver().getId() == user.getId()) {
				myMessages.add(m);
			}
		return myMessages;
	}

	@Override
	public ChatHistory saveChatHistory(ChatHistory chathistory) {
		DBUtil.chathistory.add(chathistory);
		return chathistory;
	}

	@Override
	public List<ChatHistory> getAllChatHistory() {
		return DBUtil.chathistory;
	}

}
