package com.cg.chatbox.controller;

import java.util.List;

import javax.persistence.criteria.CriteriaBuilder.In;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;
import com.cg.chatbox.service.ChatHistoryService;

@Controller
public class Mycontroller {

	@Autowired
	ChatHistoryService service;

	@RequestMapping(name = "login", method = RequestMethod.GET)
	// @GetMapping(value = "login")
	public String page() {
		return "option";
	}

	/*
	 * @PostMapping("checkLogin") public String doLogin(@RequestParam("uname")
	 * String user, @RequestParam("upass") String pass) {
	 * System.out.println("Logged In"); if (user.equals("admin") &&
	 * pass.equals("1234")) { return "option"; } else { return "error"; } }
	 */

	@GetMapping(value = "addinfo")
	public ModelAndView addMessage(@ModelAttribute("message") Message message) {
		return new ModelAndView("added");
	}

	@PostMapping("add")
	public ModelAndView addAllMessage(@ModelAttribute("message") Message message) {
		// System.out.println(message);
		Message mymessage = service.addMessage(message);
		System.out.println(mymessage);
		return new ModelAndView("option", "key", mymessage);
	}

	@GetMapping("show")
	public ModelAndView show() {
		List<ChatHistory> chathisList = service.getAllChatHistory();
		return new ModelAndView("showall", "showkey", chathisList);
	}
	
	@GetMapping("searchuser")
	public ModelAndView getUser() {
		return new ModelAndView("searchu");
	}
	@PostMapping("searchinguser")
	public ModelAndView getSearcheduser(@RequestParam("id") int id, Model m) {
		User user = service.searchUser(id);
		m.addAttribute("k",user);
		return new ModelAndView("searchu");
	}

	@GetMapping("search")
	public ModelAndView search(@ModelAttribute("user") User user) {
		return new ModelAndView("searchmessage","user",user);
	}

	@PostMapping("searchmsg")
	public ModelAndView searchMessage(@RequestParam("user") String id,Model m) {
		int result = Integer.parseInt(id);
		getSearcheduser(result,m);
//		m.addAttribute("searchkey", message);
		return new ModelAndView("searchmessage");
	}

}
