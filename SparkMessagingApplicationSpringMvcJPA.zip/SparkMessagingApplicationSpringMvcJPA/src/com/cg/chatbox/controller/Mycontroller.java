package com.cg.chatbox.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.exception.UserException;
import com.cg.chatbox.service.ChatHistoryService;

@Controller
public class Mycontroller {

	@Autowired
	ChatHistoryService service;

	ChatHistory chat;

	@RequestMapping(name = "login", method = RequestMethod.GET)
	// @GetMapping(value = "login")
	public String page() {
		return "option";
	}

	@GetMapping(value = "addinfo")
	public ModelAndView addMessage(@ModelAttribute("message") Message message) {
		return new ModelAndView("added");
	}

	@PostMapping("add")
	public ModelAndView addAllMessage(@ModelAttribute("message") Message message) {
		Message mymessage = service.addMessage(message);
		return new ModelAndView("added", "key", mymessage);
	}

	@GetMapping("show")
	public ModelAndView show() {
		List<ChatHistory> chathisList = service.getAllChatHistory();
		return new ModelAndView("showall", "showkey", chathisList);
	}

	@GetMapping("search")
	public ModelAndView search() {
		return new ModelAndView("searchmessage");
	}

	@PostMapping("searchmsg")
	public ModelAndView searchMessage(@RequestParam("userid") int id, Model m) {
		List<Message> msgList = service.searchBySenderOrReceiver(id);
		m.addAttribute("mk", msgList);
		return new ModelAndView("searchmessage", "mk", msgList);
	}

	@ExceptionHandler(UserException.class)
	public ModelAndView handlePlayerException(UserException u) {

		ModelAndView model = new ModelAndView("error/error");

		model.addObject("errmsgkey", u.getMessage());

		return model;

	}
}
