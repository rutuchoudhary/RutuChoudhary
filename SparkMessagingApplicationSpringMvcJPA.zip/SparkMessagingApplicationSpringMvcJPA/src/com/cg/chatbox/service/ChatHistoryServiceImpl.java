package com.cg.chatbox.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.chatbox.dao.ChatHistoryDao;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.exception.UserException;

@Transactional
@Service
public class ChatHistoryServiceImpl implements ChatHistoryService {
	@Autowired
	ChatHistoryDao dao;

	static int msg_id = 1;

	@Override
	public Message addMessage(Message message) {
		message.setId(msg_id);
		msg_id++;
		Message msg = dao.saveMessage(message);
		if(msg.getSender().getId()== null) {
			throw new UserException("User With Same Id Already Present Try Adding with Another Id");
		}
		return msg;
	}

	@Override
	public List<Message> searchBySenderOrReceiver(Integer id) throws UserException {
		List<Message> msgList = dao.findBySenderOrReceiver(id);
		if (msgList.isEmpty()) {
			throw new UserException("There are no messages against entered id because no user with this id");
		}
		return msgList;
	}

	@Override
	public List<ChatHistory> getAllChatHistory() {
		return dao.getAllChatHistory();
	}

}
