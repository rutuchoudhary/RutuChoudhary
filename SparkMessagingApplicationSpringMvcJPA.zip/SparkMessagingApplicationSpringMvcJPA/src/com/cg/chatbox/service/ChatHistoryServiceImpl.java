package com.cg.chatbox.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.chatbox.dao.ChatHistoryDao;
import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

@Transactional
@Service
public class ChatHistoryServiceImpl implements ChatHistoryService {
	@Autowired
	ChatHistoryDao dao;

	@Override
	public User searchUser(int id) {
		return dao.searchUser(id);
	}

	@Override
	public Message addMessage(Message message) {
		return dao.saveMessage(message);
	}

	@Override
	public List<Message> searchBySenderOrReceiver(User user) {
		return dao.findBySenderOrReceiver(user);
	}

	@Override
	public ChatHistory addChatHistory(ChatHistory chathistory) {
		return dao.saveChatHistory(chathistory);
	}

	@Override
	public List<ChatHistory> getAllChatHistory() {
		return dao.getAllChatHistory();
	}

}
