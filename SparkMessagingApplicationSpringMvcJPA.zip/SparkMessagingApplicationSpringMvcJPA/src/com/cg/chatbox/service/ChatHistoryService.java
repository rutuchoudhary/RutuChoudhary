package com.cg.chatbox.service;

import java.util.List;

import com.cg.chatbox.dto.ChatHistory;
import com.cg.chatbox.dto.Message;
import com.cg.chatbox.dto.User;

public interface ChatHistoryService {

	public User searchUser(int id);

	public Message addMessage(Message message);

	public List<Message> searchBySenderOrReceiver(User user);

	public ChatHistory addChatHistory(ChatHistory chathistory);

	public List<ChatHistory> getAllChatHistory();
}
